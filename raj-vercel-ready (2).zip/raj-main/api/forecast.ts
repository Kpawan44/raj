import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI, Type } from '@google/genai';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const { jobCards, movements } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not defined');
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const prompt = `Analyze the following job cards and historical movements to estimate job completion dates.
        Job Cards: ${JSON.stringify(jobCards)}
        Movements: ${JSON.stringify(movements)}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an operations expert analyzing manufacturing production flows. Review the job card metadata, required quantities, pending balances, and historical material movements to estimate highly structured completion dates for each job card.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              jobCardNo: {
                type: Type.STRING,
                description: 'The unique job card number identifier.'
              },
              estimatedCompletionDate: {
                type: Type.STRING,
                description: "Estimated date or duration of completion (e.g. '2026-06-25' or 'In Progress' or '2 days')."
              },
              reasoning: {
                type: Type.STRING,
                description: 'Brief reasoning/analysis for this duration/estimate.'
              }
            },
            required: ['jobCardNo', 'estimatedCompletionDate']
          }
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response received from Gemini API');
    }

    res.status(200).json(JSON.parse(text));
  } catch (error) {
    console.error('Forecast API error:', error);
    res.status(500).json({ error: 'Failed to generate forecast' });
  }
}
