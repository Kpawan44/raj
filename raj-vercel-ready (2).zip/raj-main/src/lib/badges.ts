// Centralized status → color-class mappings so badge styling isn't
// duplicated (and allowed to drift) across every view that shows a status.

/** Compact badge style used in dense table rows (App.tsx "All Orders" grid). */
export function getStatusBadgeStyleCompact(status: string): string {
  switch (status) {
    case 'Pending':
      return 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/30';
    case 'In Process':
      return 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-900/30';
    case 'Completed':
      return 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/30';
    case 'Rejected':
      return 'bg-red-100 text-red-800 border-red-200 dark:bg-red-950/40 dark:text-red-400 dark:border-red-900/30';
    case 'Pending Acceptance':
      return 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/40 dark:text-purple-400 dark:border-purple-900/30';
    default:
      return 'bg-slate-105';
  }
}

/** Bordered badge style used inside department workbench cards. */
export function getStatusBadgeStyleBordered(status: string): string {
  switch (status) {
    case 'Pending':
      return 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/40 border border-amber-200';
    case 'In Process':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-900/40 border border-blue-200';
    case 'Completed':
      return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/40 border border-emerald-200';
    case 'Rejected':
      return 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400 dark:border-red-900/40 border border-red-200';
    case 'Pending Acceptance':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-950/40 dark:text-purple-400 dark:border-purple-900/40 border border-purple-200';
    default:
      return 'bg-slate-105';
  }
}
