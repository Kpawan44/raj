import { JobCard, MaterialMovement, Department } from '../types';

/** Shape returned by each `complete*` builder: what to write to the job card, plus the handoff movement to create. */
export interface DeptCompletionResult {
  jobUpdates: Partial<JobCard>;
  movement: {
    jobCardNo: string;
    fromDepartment: Department;
    toDepartment: Department | 'Completed';
    quantity: number;
    remarks?: string;
  };
}

function sumMovements(movements: MaterialMovement[], jobCardNo: string, predicate: (m: MaterialMovement) => boolean): number {
  return movements
    .filter(m => m.jobCardNo.toLowerCase() === jobCardNo.toLowerCase() && predicate(m))
    .reduce((sum, m) => sum + m.quantity, 0);
}

export function completeProduction(
  job: JobCard,
  movements: MaterialMovement[],
  opts: { operatorName: string; qty: number }
): DeptCompletionResult | null {
  if (!opts.operatorName || opts.qty <= 0) return null;

  const totalMovedFromProdBefore = sumMovements(movements, job.jobCardNo, m => m.fromDepartment === 'Production');
  const totalProducedIncludingCurrent = totalMovedFromProdBefore + opts.qty;
  const targetDept: Department = job.heatTreatmentRequired ? 'Heat Treatment' : 'Plating';

  return {
    jobUpdates: {
      operatorName: opts.operatorName,
      currentQty: opts.qty,
      balanceQty: Math.max(0, job.orderQty - totalProducedIncludingCurrent)
    },
    movement: {
      jobCardNo: job.jobCardNo,
      fromDepartment: 'Production',
      toDepartment: targetDept,
      quantity: opts.qty,
      remarks: `Produced by ${opts.operatorName}. Sent to ${targetDept}.`
    }
  };
}

export function completeHeatTreatment(
  job: JobCard,
  opts: { hardness: string; temp: string; duration: string; rejectionQty: number; qtyReceived: number; qtySentToPlating: number }
): DeptCompletionResult | null {
  const { hardness, temp, duration, rejectionQty, qtyReceived, qtySentToPlating } = opts;

  if (qtySentToPlating > qtyReceived) {
    alert(`Error: Sent quantity (${qtySentToPlating} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }
  if (qtySentToPlating + rejectionQty > qtyReceived) {
    alert(`Error: Combined sent quantity (${qtySentToPlating} KG) and rejection quantity (${rejectionQty} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }

  const remainingQty = Math.max(0, qtyReceived - qtySentToPlating - rejectionQty);
  const prevHT = job.heatTreatmentDetails;
  const totalRejectionInHT = (prevHT?.rejectionQty || 0) + rejectionQty;

  return {
    jobUpdates: {
      customRoutedToPlating: (job.customRoutedToPlating || 0) + qtySentToPlating,
      balanceQty: Math.max(0, (job.balanceQty ?? job.orderQty) - rejectionQty),
      heatTreatmentDetails: {
        hardnessRequired: hardness,
        temperature: temp,
        cycleTime: duration,
        rejectionQty: totalRejectionInHT,
        qtyReceivedFromProd: (prevHT?.qtyReceivedFromProd || 0) + qtyReceived,
        qtySentToPlating: (prevHT?.qtySentToPlating || 0) + qtySentToPlating,
        qtyRemaining: remainingQty
      }
    },
    movement: {
      jobCardNo: job.jobCardNo,
      fromDepartment: 'Heat Treatment',
      toDepartment: 'Plating',
      quantity: qtySentToPlating,
      remarks: `Completed furnace cycle. Hardness: ${hardness}. Recv: ${qtyReceived} KG, Sent to Plating: ${qtySentToPlating} KG, Rejections: ${rejectionQty} KG, Remaining: ${remainingQty} KG.`
    }
  };
}

export function completePlating(
  job: JobCard,
  opts: { platingType: string; thickness: string; duration: string; rejectionQty: number; qtyReceived: number; qtySentToPacking: number }
): DeptCompletionResult | null {
  const { platingType, thickness, duration, rejectionQty, qtyReceived, qtySentToPacking } = opts;

  if (qtySentToPacking > qtyReceived) {
    alert(`Error: Sent quantity (${qtySentToPacking} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }
  if (qtySentToPacking + rejectionQty > qtyReceived) {
    alert(`Error: Combined sent quantity (${qtySentToPacking} KG) and rejection quantity (${rejectionQty} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }

  const remainingQty = Math.max(0, qtyReceived - qtySentToPacking - rejectionQty);
  const prevPlating = job.platingDetails;
  const totalRejectionInPlating = (prevPlating?.rejectionQty || 0) + rejectionQty;

  return {
    jobUpdates: {
      customRoutedToPacking: (job.customRoutedToPacking || 0) + qtySentToPacking,
      balanceQty: Math.max(0, (job.balanceQty ?? job.orderQty) - rejectionQty),
      platingDetails: {
        platingType,
        micronThickness: thickness,
        durationMinutes: duration,
        rejectionQty: totalRejectionInPlating,
        qtyReceivedFromHt: (prevPlating?.qtyReceivedFromHt || 0) + qtyReceived,
        qtySentToPacking: (prevPlating?.qtySentToPacking || 0) + qtySentToPacking,
        qtyRemaining: remainingQty
      }
    },
    movement: {
      jobCardNo: job.jobCardNo,
      fromDepartment: 'Plating',
      toDepartment: 'Packing',
      quantity: qtySentToPacking,
      remarks: `Coating thickness ${thickness} verified. Zinc plating cycle complete. Recv from HT: ${qtyReceived} KG, Sent for Packing: ${qtySentToPacking} KG, Rejections: ${rejectionQty} KG, Remaining Balance: ${remainingQty} KG.`
    }
  };
}

export function completePacking(
  job: JobCard,
  opts: { boxCount: number; packStyle: string; rejectionQty: number; qtyReceived: number; qtySentToStore: number }
): DeptCompletionResult | null {
  const { boxCount, packStyle, rejectionQty, qtyReceived, qtySentToStore } = opts;

  if (qtySentToStore > qtyReceived) {
    alert(`Error: Sent quantity (${qtySentToStore} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }
  if (qtySentToStore + rejectionQty > qtyReceived) {
    alert(`Error: Combined sent quantity (${qtySentToStore} KG) and rejection quantity (${rejectionQty} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }

  const remainingQty = Math.max(0, qtyReceived - qtySentToStore - rejectionQty);
  const prevPacking = job.packingDetails;
  const totalPackedIncludingCurrent = (prevPacking?.qtySentToStore || 0) + qtySentToStore;

  const htRejectionTotal = job.heatTreatmentDetails?.rejectionQty || 0;
  const platingRejectionTotal = job.platingDetails?.rejectionQty || 0;
  const packingRejectionTotal = (prevPacking?.rejectionQty || 0) + rejectionQty;
  const totalRejections = htRejectionTotal + platingRejectionTotal + packingRejectionTotal;

  return {
    jobUpdates: {
      customRoutedToStore: (job.customRoutedToStore || 0) + qtySentToStore,
      packingDetails: {
        packedQty: totalPackedIncludingCurrent,
        boxCount: (prevPacking?.boxCount || 0) + boxCount,
        packingType: packStyle,
        rejectionQty: packingRejectionTotal,
        qtyReceivedFromPlating: (prevPacking?.qtyReceivedFromPlating || 0) + qtyReceived,
        qtySentToStore: totalPackedIncludingCurrent,
        qtyRemaining: remainingQty
      },
      currentQty: qtySentToStore,
      balanceQty: Math.max(0, job.orderQty - totalPackedIncludingCurrent - totalRejections)
    },
    movement: {
      jobCardNo: job.jobCardNo,
      fromDepartment: 'Packing',
      toDepartment: 'Store',
      quantity: qtySentToStore,
      remarks: `Packed in ${boxCount} boxes. Quality verified. Recv from Plating: ${qtyReceived} KG, Sent to Store: ${qtySentToStore} KG, Rejections: ${rejectionQty} KG, Remaining: ${remainingQty} KG.`
    }
  };
}

export function completeStore(
  job: JobCard,
  opts: { binLoc: string; rejectionQty: number; qtyReceived: number; qtySentToDispatch: number }
): DeptCompletionResult | null {
  const { binLoc, rejectionQty, qtyReceived, qtySentToDispatch } = opts;

  if (qtySentToDispatch > qtyReceived) {
    alert(`Error: Sent quantity (${qtySentToDispatch} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }
  if (qtySentToDispatch + rejectionQty > qtyReceived) {
    alert(`Error: Combined sent quantity (${qtySentToDispatch} KG) and rejection quantity (${rejectionQty} KG) cannot exceed the received quantity (${qtyReceived} KG).`);
    return null;
  }

  const remainingQty = Math.max(0, qtyReceived - qtySentToDispatch - rejectionQty);

  return {
    jobUpdates: {
      storeDetails: {
        verifiedQty: qtySentToDispatch,
        locationBin: binLoc,
        rejectionQty,
        qtyReceivedFromPacking: qtyReceived,
        qtySentToDispatch,
        qtyRemaining: remainingQty
      },
      currentQty: qtySentToDispatch,
      balanceQty: Math.max(0, job.orderQty - qtySentToDispatch)
    },
    movement: {
      jobCardNo: job.jobCardNo,
      fromDepartment: 'Store',
      toDepartment: 'Dispatch',
      quantity: qtySentToDispatch,
      remarks: `Stored in bin location: ${binLoc}. Ingested into active system ledger. Recv from Packing: ${qtyReceived} KG, Sent to Dispatch: ${qtySentToDispatch} KG, Rejections: ${rejectionQty} KG, Remaining Qty: ${remainingQty} KG.`
    }
  };
}

/** Dispatch finalization doesn't create a new movement — it closes the job card and accepts the pending Dispatch-bound movement. */
export function buildDispatchFinalizationUpdates(
  job: JobCard,
  opts: { invoiceNo: string; vehicleNo: string; qty: number }
): Partial<JobCard> | null {
  if (opts.qty <= 0 || !opts.invoiceNo || !opts.vehicleNo) return null;

  return {
    completed: true,
    status: 'Completed',
    currentQty: opts.qty,
    balanceQty: Math.max(0, job.orderQty - opts.qty),
    dispatchDetails: {
      invoiceNo: opts.invoiceNo,
      vehicleNo: opts.vehicleNo,
      dispatchQty: opts.qty,
      dispatchDate: new Date().toISOString(),
      remarks: `Outbound loaded onto ${opts.vehicleNo}. Bill of lading issued.`
    }
  };
}
