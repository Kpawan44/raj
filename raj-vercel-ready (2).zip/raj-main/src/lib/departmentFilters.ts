import { JobCard, MaterialMovement, Department } from '../types';
import { getJobCardProcessMetrics } from './metrics';

/** Sum of quantity moved matching a predicate — small helper to cut down repetition below. */
function sumMovements(movements: MaterialMovement[], predicate: (m: MaterialMovement) => boolean): number {
  return movements.filter(predicate).reduce((sum, m) => sum + m.quantity, 0);
}

/**
 * Job cards that are "in this department's court" right now — either
 * currently parked there, or still carrying a pending balance that hasn't
 * been fully routed onward.
 */
export function getActiveDepartmentJobs(
  activeDept: Department,
  jobCards: JobCard[],
  movements: MaterialMovement[]
): JobCard[] {
  return jobCards.filter(c => {
    if (c.completed) return false;

    if (activeDept === 'Dispatch') {
      return true;
    }

    if (activeDept === 'Production') {
      const totalMovedFromProd = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.fromDepartment === 'Production'
      );
      const pendingProdQty = c.orderQty - totalMovedFromProd;
      return c.currentDepartment === 'Production' || pendingProdQty > 0;
    }

    if (activeDept === 'Heat Treatment') {
      if (!c.heatTreatmentRequired) return false;
      const totalReceivedAtHT = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.toDepartment === 'Heat Treatment' && m.accepted
      );
      const totalRoutedFromHT = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.fromDepartment === 'Heat Treatment'
      );
      const pendingHTQty = totalReceivedAtHT - totalRoutedFromHT - (c.heatTreatmentDetails?.rejectionQty || 0);
      return c.currentDepartment === 'Heat Treatment' || (totalReceivedAtHT > 0 && pendingHTQty > 0);
    }

    if (activeDept === 'Plating') {
      const totalReceivedAtPlating = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.toDepartment === 'Plating' && m.accepted
      );
      const totalRoutedFromPlating = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.fromDepartment === 'Plating'
      );
      const pendingPlatingQty = totalReceivedAtPlating - totalRoutedFromPlating - (c.platingDetails?.rejectionQty || 0);
      return c.currentDepartment === 'Plating' || (totalReceivedAtPlating > 0 && pendingPlatingQty > 0);
    }

    if (activeDept === 'Packing') {
      const totalReceivedAtPacking = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.toDepartment === 'Packing' && m.accepted
      );
      const totalRoutedFromPacking = sumMovements(movements, m =>
        m.jobCardNo.toLowerCase() === c.jobCardNo.toLowerCase() && m.fromDepartment === 'Packing'
      );
      const pendingPackingQty = totalReceivedAtPacking - totalRoutedFromPacking - (c.packingDetails?.rejectionQty || 0);
      return c.currentDepartment === 'Packing' || (totalReceivedAtPacking > 0 && pendingPackingQty > 0);
    }

    return c.currentDepartment === activeDept;
  });
}

/** Movements inbound to this department still awaiting acceptance. */
export function getIncomingTransfers(activeDept: Department, movements: MaterialMovement[]): MaterialMovement[] {
  return movements.filter(m => m.toDepartment === activeDept && !m.accepted);
}

/** Movements this department has already handed off downstream. */
export function getCompletedDepartmentLogs(activeDept: Department, movements: MaterialMovement[]): MaterialMovement[] {
  return movements.filter(m => m.fromDepartment === activeDept && m.accepted);
}

/** Per-job display metrics for the active department's row summary (received/routed/pending/custody). */
export interface JobDeptDisplayMetrics {
  totalReceived: number;
  totalRouted: number;
  pendingQty: number;
  isRoutedDownstream: boolean;
}

export function getJobDeptDisplayMetrics(
  job: JobCard,
  movements: MaterialMovement[],
  activeDept: Department
): JobDeptDisplayMetrics {
  const m = getJobCardProcessMetrics(job, movements);
  const byJob = (predicate: (m: MaterialMovement) => boolean) =>
    sumMovements(movements, mv => mv.jobCardNo.toLowerCase() === job.jobCardNo.toLowerCase() && predicate(mv));

  if (activeDept === 'Production') {
    const totalMovedFromProd = byJob(mv => mv.fromDepartment === 'Production');
    return {
      totalReceived: job.orderQty,
      totalRouted: totalMovedFromProd,
      pendingQty: job.orderQty - totalMovedFromProd,
      isRoutedDownstream: job.currentDepartment !== 'Production'
    };
  }

  if (activeDept === 'Heat Treatment') {
    const totalReceivedAtHT = byJob(mv => mv.toDepartment === 'Heat Treatment' && mv.accepted);
    const htInputDisplay = totalReceivedAtHT > 0 ? totalReceivedAtHT : (job.currentDepartment === 'Heat Treatment' ? m.qtyReceivedFromProd : 0);
    const totalRoutedFromHT = byJob(mv => mv.fromDepartment === 'Heat Treatment');
    return {
      totalReceived: htInputDisplay,
      totalRouted: totalRoutedFromHT,
      pendingQty: Math.max(0, htInputDisplay - totalRoutedFromHT - (job.heatTreatmentDetails?.rejectionQty || 0)),
      isRoutedDownstream: job.currentDepartment !== 'Heat Treatment'
    };
  }

  if (activeDept === 'Plating') {
    const totalReceivedAtPlating = byJob(mv => mv.toDepartment === 'Plating' && mv.accepted);
    const platingInputDisplay = totalReceivedAtPlating > 0 ? totalReceivedAtPlating : (job.currentDepartment === 'Plating' ? m.qtyReceivedAtPlating : 0);
    const totalRoutedFromPlating = byJob(mv => mv.fromDepartment === 'Plating');
    return {
      totalReceived: platingInputDisplay,
      totalRouted: totalRoutedFromPlating,
      pendingQty: Math.max(0, platingInputDisplay - totalRoutedFromPlating - (job.platingDetails?.rejectionQty || 0)),
      isRoutedDownstream: job.currentDepartment !== 'Plating'
    };
  }

  if (activeDept === 'Packing') {
    const totalReceivedAtPacking = byJob(mv => mv.toDepartment === 'Packing' && mv.accepted);
    const packingInputDisplay = totalReceivedAtPacking > 0 ? totalReceivedAtPacking : (job.currentDepartment === 'Packing' ? m.qtyReceivedAtPacking : 0);
    const totalRoutedFromPacking = byJob(mv => mv.fromDepartment === 'Packing');
    return {
      totalReceived: packingInputDisplay,
      totalRouted: totalRoutedFromPacking,
      pendingQty: Math.max(0, packingInputDisplay - totalRoutedFromPacking - (job.packingDetails?.rejectionQty || 0)),
      isRoutedDownstream: job.currentDepartment !== 'Packing'
    };
  }

  return { totalReceived: 0, totalRouted: 0, pendingQty: 0, isRoutedDownstream: false };
}
