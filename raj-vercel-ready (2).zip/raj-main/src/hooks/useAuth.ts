import React, { useState } from 'react';
import { DBService } from '../lib/firebase';
import { UserProfile } from '../types';

const SESSION_KEY = 'mfr_active_user_uid';

export function useAuth(users: UserProfile[]) {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loginName, setLoginName] = useState('');
  const [loginPin, setLoginPin] = useState('');
  const [authError, setAuthError] = useState('');

  const [isRegistering, setIsRegistering] = useState(false);
  const [regName, setRegName] = useState('');
  const [regSuccess, setRegSuccess] = useState('');

  /** Called after every data refresh so a saved session survives a page reload. */
  const restoreSessionIfNeeded = (freshUsers: UserProfile[]) => {
    const savedUserUid = sessionStorage.getItem(SESSION_KEY);
    if (savedUserUid && !currentUser) {
      const found = freshUsers.find(u => u.userId === savedUserUid);
      if (found) setCurrentUser(found);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setRegSuccess('');

    const trimmedName = loginName.trim();
    if (!trimmedName) {
      setAuthError('Name is required.');
      return;
    }

    const found = users.find(u => u.name.toLowerCase() === trimmedName.toLowerCase() && u.active);
    if (!found) {
      setAuthError('Invalid credentials. Check your name.');
      return;
    }

    setCurrentUser(found);
    sessionStorage.setItem(SESSION_KEY, found.userId);
    setLoginName('');
    setLoginPin('');
    DBService.logAction(found.userId, found.name, 'USER_LOGIN', `Logged in.`);
  };

  const handleRegisterUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setRegSuccess('');

    const trimmedName = regName.trim();
    if (!trimmedName) {
      setAuthError('Name is required.');
      return;
    }

    const nameExists = users.some(u => u.name.toLowerCase() === trimmedName.toLowerCase());
    if (nameExists) {
      setAuthError('User name is already registered.');
      return;
    }

    const newUserId = `u-${Date.now()}`;
    const newProfile: UserProfile = {
      userId: newUserId,
      name: trimmedName,
      email: `${trimmedName.toLowerCase().replace(/\s+/g, '')}@factory.com`,
      pin: '0000',
      department: 'Admin',
      role: 'admin',
      active: true,
      createdAt: new Date().toISOString()
    };

    try {
      await DBService.saveUser(newProfile);

      await DBService.createNotification({
        department: 'All',
        title: 'New Manager Onboarded',
        message: `Manager ${trimmedName} registered with administrative access.`,
        userId: newUserId
      });

      setRegSuccess(`Manager account successfully created for ${trimmedName}! Please log in below.`);
      setLoginName(trimmedName);
      setRegName('');
      setIsRegistering(false);
    } catch (err) {
      setAuthError('Could not process registration.');
      console.error(err);
    }
  };

  const handleDemoQuickLogin = (user: UserProfile) => {
    setLoginName(user.name);
    setLoginPin(user.pin);
    setCurrentUser(user);
    sessionStorage.setItem(SESSION_KEY, user.userId);
    DBService.logAction(user.userId, user.name, 'USER_LOGIN', `Logged in via quick demo selector.`);
  };

  const handleLogout = () => {
    if (currentUser) {
      DBService.logAction(currentUser.userId, currentUser.name, 'USER_LOGOUT', 'Logged out of terminal');
    }
    setCurrentUser(null);
    sessionStorage.removeItem(SESSION_KEY);
  };

  const handleSwitchUserSimulated = (userId: string) => {
    const found = users.find(u => u.userId === userId);
    if (found) {
      setCurrentUser(found);
      sessionStorage.setItem(SESSION_KEY, found.userId);
      DBService.logAction(found.userId, found.name, 'SWITCH_ROLE', `Simulated operation shift switched department to ${found.department}`);
    }
  };

  return {
    currentUser,
    setCurrentUser,
    loginName, setLoginName,
    loginPin, setLoginPin,
    authError, setAuthError,
    isRegistering, setIsRegistering,
    regName, setRegName,
    regSuccess, setRegSuccess,
    restoreSessionIfNeeded,
    handleLogin,
    handleRegisterUser,
    handleDemoQuickLogin,
    handleLogout,
    handleSwitchUserSimulated
  };
}
