import { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { DBService, auth } from '../lib/firebase';
import {
  getSpreadsheetDetails,
  isSheetsConnected,
  setGoogleAccessToken,
  initializeSpreadsheet,
  disconnectSheets
} from '../lib/googleSheets';
import { UserProfile } from '../types';

export function useGoogleSheetsSync(currentUser: UserProfile | null) {
  const [sheetsDetails, setSheetsDetails] = useState(getSpreadsheetDetails());
  const [isSheetsActive, setIsSheetsActive] = useState(isSheetsConnected());
  const [showSheetsModal, setShowSheetsModal] = useState(false);
  const [sheetsFeedback, setSheetsFeedback] = useState('');

  const handleConnectGoogleSheets = async () => {
    setSheetsFeedback('Connecting to Google Account...');
    try {
      const provider = new GoogleAuthProvider();
      provider.addScope('https://www.googleapis.com/auth/spreadsheets');
      provider.addScope('https://www.googleapis.com/auth/drive.file');

      let token = '';
      if (auth) {
        const result = await signInWithPopup(auth, provider);
        const credential = GoogleAuthProvider.credentialFromResult(result);
        token = credential?.accessToken || '';
      } else {
        token = 'dev-simulated-token-99933211-' + Math.random().toString(36).substring(7);
      }

      if (!token) {
        throw new Error("Missing Google Access Token. Please approve requested permissions.");
      }

      setGoogleAccessToken(token);
      setSheetsFeedback('Initializing "Factory Material Flow Ledger" Google Sheets tabs...');

      await initializeSpreadsheet();
      const details = getSpreadsheetDetails();
      setSheetsDetails(details);
      setIsSheetsActive(true);
      setSheetsFeedback('');
      setShowSheetsModal(false);

      await DBService.logAction(
        currentUser?.userId || 'unknown',
        currentUser?.name || 'unknown',
        'CONNECT_GOOGLE_SHEETS',
        `Linked Google Spreadsheet "${details.name}" for live ledger synchronization.`
      );
    } catch (err: any) {
      console.error(err);
      setSheetsFeedback('Failed: ' + err.message);
    }
  };

  const handleDisconnectGoogleSheets = async () => {
    disconnectSheets();
    setIsSheetsActive(false);
    setSheetsDetails(getSpreadsheetDetails());

    await DBService.logAction(
      currentUser?.userId || 'unknown',
      currentUser?.name || 'unknown',
      'DISCONNECT_GOOGLE_SHEETS',
      `Unlinked Google Spreadsheet ledger connection.`
    );
  };

  return {
    sheetsDetails,
    isSheetsActive,
    showSheetsModal, setShowSheetsModal,
    sheetsFeedback, setSheetsFeedback,
    handleConnectGoogleSheets,
    handleDisconnectGoogleSheets
  };
}
