import { useEffect, useState } from 'react';
import { DBService } from '../lib/firebase';
import { UserProfile, JobCard, MaterialMovement, AppNotification, AuditLog, CompanyConfig } from '../types';

/**
 * Owns the core Firestore-backed collections and keeps them fresh via
 * realtime subscriptions. Deliberately knows nothing about auth or routing —
 * callers pass in the bits they want kept in sync (selected job, restored
 * session) via small callbacks.
 */
export function useAppData(opts: {
  onSessionRestore: (users: UserProfile[]) => void;
  onDeepLinkJobCard: (jobCards: JobCard[]) => void;
  reconcileSelectedJob: (jobCards: JobCard[]) => void;
}) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [jobCards, setJobCards] = useState<JobCard[]>([]);
  const [movements, setMovements] = useState<MaterialMovement[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [companyConfig, setCompanyConfig] = useState<CompanyConfig | null>(null);

  const refreshAllStates = async () => {
    try {
      const u = await DBService.getUsers();
      const jc = await DBService.getJobCards();
      const mov = await DBService.getMovements();
      const n = await DBService.getNotifications();
      const logs = await DBService.getAuditLogs();
      const config = await DBService.getCompanyConfig();

      setUsers(u);
      setJobCards(jc);
      setMovements(mov);
      setNotifications(n);
      setAuditLogs(logs);
      setCompanyConfig(config);

      opts.reconcileSelectedJob(jc);
      opts.onSessionRestore(u);
      opts.onDeepLinkJobCard(jc);
    } catch (err) {
      console.error("Failed to batch load local firestore fallback", err);
    }
  };

  useEffect(() => {
    refreshAllStates();

    const unsubUsers = DBService.subscribeToUpdates('mfr_users', refreshAllStates);
    const unsubJobs = DBService.subscribeToUpdates('mfr_job_cards', refreshAllStates);
    const unsubMoves = DBService.subscribeToUpdates('mfr_movements', refreshAllStates);
    const unsubNotifs = DBService.subscribeToUpdates('mfr_notifications', refreshAllStates);
    const unsubAudits = DBService.subscribeToUpdates('mfr_audit_logs', refreshAllStates);
    const unsubCompany = DBService.subscribeToUpdates('mfr_company_config', refreshAllStates);

    return () => {
      unsubUsers();
      unsubJobs();
      unsubMoves();
      unsubNotifs();
      unsubAudits();
      unsubCompany();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { users, jobCards, movements, notifications, auditLogs, companyConfig, refreshAllStates };
}
