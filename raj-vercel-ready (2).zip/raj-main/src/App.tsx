import React, { useEffect, useState } from 'react';
import { DBService } from './lib/firebase';
import { UserProfile, JobCard, MaterialMovement, Department, JobCardStatus } from './types';
import Sidebar from './components/Sidebar';
import DashboardStats from './components/DashboardStats';
import DepartmentOperations from './components/DepartmentOperations';
import ForecastView from './components/ForecastView';
import JobCardDetailsModal from './components/JobCardDetailsModal';
import ScannerModal from './components/ScannerModal';
import ReportView from './components/ReportView';
import AdminConsole from './components/AdminConsole';
import LoginScreen from './components/LoginScreen';
import TopBar from './components/TopBar';
import AllOrdersView from './components/AllOrdersView';
import TimelineLiveView from './components/TimelineLiveView';
import GoogleSheetsModal from './components/GoogleSheetsModal';
import { useAppData } from './hooks/useAppData';
import { useAuth } from './hooks/useAuth';
import { useGoogleSheetsSync } from './hooks/useGoogleSheetsSync';

export default function App() {
  // --- VIEWPORT / UI STATE ---
  const [activeTab, setActiveTab] = useState<'dashboard' | 'all-orders' | 'timeline-live' | 'reports' | 'admin-users' | string>('dashboard');
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024;
    }
    return false;
  });
  const [selectedJob, setSelectedJob] = useState<JobCard | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);

  // --- AUTH (needs `users`, so it's wired up after useAppData below via a small indirection) ---
  const [users, setUsersMirror] = useState<UserProfile[]>([]);
  const authApi = useAuth(users);
  const { currentUser, setCurrentUser } = authApi;

  const {
    jobCards,
    movements,
    notifications,
    auditLogs,
    companyConfig,
    refreshAllStates
  } = useAppData({
    onSessionRestore: (freshUsers) => {
      setUsersMirror(freshUsers);
      authApi.restoreSessionIfNeeded(freshUsers);
    },
    onDeepLinkJobCard: (jc) => {
      const urlParams = new URLSearchParams(window.location.search);
      const queryJobCardNo = urlParams.get('jobCardNo');
      if (queryJobCardNo && jc.length > 0) {
        const foundJob = jc.find(j => j.jobCardNo.toLowerCase() === queryJobCardNo.toLowerCase());
        if (foundJob) {
          setSelectedJob(foundJob);
          const newUrl = window.location.pathname;
          window.history.replaceState({}, document.title, newUrl);
        }
      }
    },
    reconcileSelectedJob: (jc) => {
      setSelectedJob(prev => {
        if (!prev) return null;
        const freshJob = jc.find(j => j.jobCardNo.toLowerCase() === prev.jobCardNo.toLowerCase());
        return freshJob || prev;
      });
    }
  });

  const sheets = useGoogleSheetsSync(currentUser);

  // --- THEME ENGINE ---
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  // --- RESPONSIVE SIDEBAR AUTO-COLLAPSE ---
  useEffect(() => {
    const handleResize = () => {
      setSidebarOpen(window.innerWidth >= 1024);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // --- JOB CARD / MOVEMENT ACTIONS ---
  const handleCreateSubJob = async (parentJob: JobCard) => {
    if (!currentUser) return;

    const totalMovedQty = movements.filter(m => m.jobCardNo.toLowerCase() === parentJob.jobCardNo.toLowerCase()).reduce((acc, curr) => acc + curr.quantity, 0);
    const pendingQty = parentJob.orderQty - totalMovedQty;

    if (pendingQty <= 0) {
      alert("No pending quantity to split.");
      return;
    }
    if (!confirm(`Create new sub-job for ${pendingQty} KG from ${parentJob.jobCardNo}?`)) return;

    const subJob = {
      partyName: parentJob.partyName,
      itemName: parentJob.itemName,
      itemCode: parentJob.itemCode,
      orderQty: pendingQty,
      currentQty: pendingQty,
      currentDepartment: 'Production' as Department,
      status: 'Pending' as JobCardStatus,
      heatTreatmentRequired: parentJob.heatTreatmentRequired,
      createdBy: currentUser.name
    };

    try {
      await DBService.createJobCard(subJob, currentUser.userId, currentUser.name);
      alert(`Sub-Job successfully created for ${pendingQty} KG!`);
      refreshAllStates();
    } catch (err: any) {
      alert(`Failed to create Sub-Job: ${err.message}`);
    }
  };

  const handleCreateJobCard = async (job: any) => {
    if (!currentUser) return;
    try {
      await DBService.createJobCard(job, currentUser.userId, currentUser.name);
      alert(`Job Card successfully created!`);
      refreshAllStates();
    } catch (err: any) {
      console.error("Failed to create job card", err);
      alert(`Failed to create Job Card: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleUpdateJobCard = async (jobCardNo: string, updates: any) => {
    if (!currentUser) return;
    try {
      await DBService.updateJobCard(jobCardNo, updates, currentUser.userId, currentUser.name);
      refreshAllStates();
    } catch (err: any) {
      console.error("Failed to update job card", err);
      alert(`Failed to update Job Card: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleCreateMovement = async (mov: any) => {
    if (!currentUser) return;
    try {
      await DBService.createMovement(mov, currentUser.userId, currentUser.name);
      refreshAllStates();
    } catch (err: any) {
      console.error("Failed to transfer material", err);
      alert(`Failed to transfer material: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleAcceptMovement = async (movementId: string, remarks?: string) => {
    if (!currentUser) return;
    try {
      await DBService.acceptMovement(movementId, currentUser.userId, currentUser.name, remarks);
      refreshAllStates();
    } catch (err: any) {
      console.error("Failed to accept movement", err);
      alert(`Failed to accept material transfer: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleRejectMovement = async (movementId: string, remarks: string) => {
    if (!currentUser) return;
    try {
      await DBService.rejectMovement(movementId, currentUser.userId, currentUser.name, remarks);
      refreshAllStates();
    } catch (err: any) {
      console.error("Failed to reject movement", err);
      alert(`Failed to reject material transfer: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleSaveUserProfile = async (profile: UserProfile) => {
    await DBService.saveUser(profile);
  };

  const handleDeleteUserProfile = async (userId: string, userName: string) => {
    if (!currentUser) return;
    await DBService.deleteUser(userId, userName, currentUser.userId, currentUser.name);
  };

  const handleLogActionExternally = async (action: string, details: string) => {
    if (!currentUser) return;
    await DBService.logAction(currentUser.userId, currentUser.name, action, details);
  };

  const handleSelectJobByNo = (jobNo: string) => {
    const found = jobCards.find(j => j.jobCardNo.toLowerCase() === jobNo.toLowerCase());
    if (found) setSelectedJob(found);
  };

  // --- ATTACHMENTS MANAGER ---
  const handleUploadAttachment = async (jobCardNo: string, file: any) => {
    const card = jobCards.find(c => c.jobCardNo.toLowerCase() === jobCardNo.toLowerCase());
    if (card) {
      const files = (card as any).attachments || [];
      const updatedFiles = [...files, file];

      await DBService.updateJobCard(jobCardNo, { attachments: updatedFiles } as any, currentUser?.userId || 'unknown', currentUser?.name || 'unknown');
      await DBService.logAction(currentUser?.userId || 'unknown', currentUser?.name || 'unknown', 'UPLOAD_ATTACHMENT', `Uploaded document '${file.name}' to Job Card ${jobCardNo}`);
    }
  };

  const handleDeleteAttachment = async (jobCardNo: string, index: number) => {
    const card = jobCards.find(c => c.jobCardNo.toLowerCase() === jobCardNo.toLowerCase());
    if (card) {
      const files = (card as any).attachments || [];
      const updatedFiles = [...files];
      const removedText = updatedFiles[index]?.name || 'document';
      updatedFiles.splice(index, 1);

      await DBService.updateJobCard(jobCardNo, { attachments: updatedFiles } as any, currentUser?.userId || 'unknown', currentUser?.name || 'unknown');
      await DBService.logAction(currentUser?.userId || 'unknown', currentUser?.name || 'unknown', 'DELETE_ATTACHMENT', `Deleted document '${removedText}' from Job Card ${jobCardNo}`);
    }
  };

  // --- NOTIFICATIONS ---
  const activeDepartment = currentUser?.department === 'Admin' ? 'Admin' : currentUser?.department as Department;
  const filteredNotifications = notifications.filter(notif => {
    if (activeDepartment === 'Admin') return true;
    return notif.department === activeDepartment || notif.department === 'All';
  });
  const unreadNotificationsCount = filteredNotifications.filter(n => !n.read).length;

  const handleMarkNotifRead = async (id: string) => {
    await DBService.markNotificationRead(id);
  };

  const handleMarkAllNotifsRead = async () => {
    if (!activeDepartment) return;
    await DBService.markAllNotificationsRead(activeDepartment);
  };

  // --- RENDER LOGIN VIEW IF NO REGISTERED PROFILE ---
  if (!currentUser) {
    return (
      <LoginScreen
        users={users}
        isRegistering={authApi.isRegistering}
        setIsRegistering={authApi.setIsRegistering}
        regName={authApi.regName}
        setRegName={authApi.setRegName}
        regSuccess={authApi.regSuccess}
        setRegSuccess={authApi.setRegSuccess}
        authError={authApi.authError}
        setAuthError={authApi.setAuthError}
        loginName={authApi.loginName}
        setLoginName={authApi.setLoginName}
        onLogin={authApi.handleLogin}
        onRegister={authApi.handleRegisterUser}
        onDemoQuickLogin={authApi.handleDemoQuickLogin}
      />
    );
  }

  return (
    <div className="flex h-screen bg-[#F8FAFC] dark:bg-slate-950 transition-colors duration-200 font-sans overflow-hidden selection:bg-[#3B82F6] selection:text-white">

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden animate-fade-in"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className={`
        fixed inset-y-0 left-0 z-50 transition-all duration-300 ease-in-out flex shrink-0 h-full
        lg:static lg:z-0 lg:translate-x-0
        ${sidebarOpen ? 'translate-x-0 w-[220px]' : '-translate-x-full w-[220px] lg:w-0 lg:opacity-0 lg:overflow-hidden'}
      `}>
        <Sidebar
          currentUser={currentUser}
          availableUsers={users}
          onSwitchUser={authApi.handleSwitchUserSimulated}
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            if (window.innerWidth < 1024) {
              setSidebarOpen(false);
            }
          }}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          unreadCount={unreadNotificationsCount}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          companyConfig={companyConfig}
        />
      </div>

      <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#F8FAFC] dark:bg-slate-950">
        <TopBar
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          isSheetsActive={sheets.isSheetsActive}
          sheetsUrl={sheets.sheetsDetails.url}
          onOpenSheetsModal={() => sheets.setShowSheetsModal(true)}
          onDisconnectSheets={sheets.handleDisconnectGoogleSheets}
          onOpenScanner={() => setScannerOpen(true)}
          filteredNotifications={filteredNotifications}
          unreadNotificationsCount={unreadNotificationsCount}
          onMarkNotifRead={handleMarkNotifRead}
          onMarkAllNotifsRead={handleMarkAllNotifsRead}
          onLogout={authApi.handleLogout}
        />

        <div className="flex-1 p-6 space-y-6 overflow-y-auto bg-[#F8FAFC] dark:bg-slate-950 print:p-0 print:overflow-visible">

          {activeTab === 'dashboard' && (
            <DashboardStats
              department={currentUser.department}
              jobCards={jobCards}
              movements={movements}
            />
          )}

          {activeTab === 'dashboard' && (
            <DepartmentOperations
              currentUser={currentUser}
              jobCards={jobCards}
              movements={movements}
              onCreateJobCard={handleCreateJobCard}
              onUpdateJobCard={handleUpdateJobCard}
              onCreateMovement={handleCreateMovement}
              onAcceptMovement={handleAcceptMovement}
              onRejectMovement={handleRejectMovement}
              onSelectJobCard={setSelectedJob}
            />
          )}

          {activeTab === 'forecast' && (
            <ForecastView
              jobCards={jobCards}
              movements={movements}
            />
          )}

          {activeTab === 'all-orders' && (
            <AllOrdersView
              jobCards={jobCards}
              movements={movements}
              currentUser={currentUser}
              onSelectJobCard={setSelectedJob}
              onCreateSubJob={handleCreateSubJob}
              onRefresh={refreshAllStates}
            />
          )}

          {activeTab === 'timeline-live' && (
            <TimelineLiveView
              jobCards={jobCards}
              movements={movements}
              onSelectJobByNo={handleSelectJobByNo}
            />
          )}

          {activeTab === 'reports' && (
            <ReportView
              jobCards={jobCards}
              movements={movements}
            />
          )}

          {activeTab === 'admin-users' && (
            <AdminConsole
              users={users}
              auditLogs={auditLogs}
              onSaveUser={handleSaveUserProfile}
              onLogAction={handleLogActionExternally}
              currentUser={currentUser}
              onDeleteUser={handleDeleteUserProfile}
              jobCards={jobCards}
              movements={movements}
              onRefreshJobs={refreshAllStates}
              companyConfig={companyConfig}
              onRefreshCompany={refreshAllStates}
            />
          )}

        </div>
      </main>

      <ScannerModal
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        jobCards={jobCards}
        onSelectJobCard={handleSelectJobByNo}
      />

      {selectedJob && (
        <JobCardDetailsModal
          isOpen={!!selectedJob}
          onClose={() => setSelectedJob(null)}
          jobCard={selectedJob}
          movements={movements}
          currentUser={currentUser}
          onUploadAttachment={handleUploadAttachment}
          onDeleteAttachment={handleDeleteAttachment}
        />
      )}

      {sheets.showSheetsModal && (
        <GoogleSheetsModal
          onClose={() => { sheets.setShowSheetsModal(false); sheets.setSheetsFeedback(''); }}
          feedback={sheets.sheetsFeedback}
          onConnect={sheets.handleConnectGoogleSheets}
        />
      )}

    </div>
  );
}
