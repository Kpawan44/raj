import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { MaterialMovement } from '../../types';

interface IncomingTransfersPanelProps {
  incomingTransfers: MaterialMovement[];
  onAcceptMovement: (movementId: string, remarks?: string) => void;
  onRejectMovement: (movementId: string, remarks: string) => void;
}

export default function IncomingTransfersPanel({
  incomingTransfers,
  onAcceptMovement,
  onRejectMovement
}: IncomingTransfersPanelProps) {
  const [activeRejectionId, setActiveRejectionId] = useState<string | null>(null);
  const [rejectionNotes, setRejectionNotes] = useState('');

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
      <h3 className="font-sans font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
        📥 Pending Custody Receipts
      </h3>

      {incomingTransfers.length === 0 ? (
        <div className="text-center py-10 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
          <span className="text-2xl">📦</span>
          <p className="text-slate-400 text-xs font-mono font-medium">Floor queue clean. No pending inbound shipments found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {incomingTransfers.map(mov => {
            const isRejecting = activeRejectionId === mov.movementId;
            return (
              <div
                key={mov.movementId}
                className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-201 dark:border-slate-850 flex flex-col gap-3"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2 font-mono">
                      <span className="text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded">{mov.jobCardNo}</span>
                      <span className="text-slate-400 font-bold">Transfer Ref: {mov.movementId}</span>
                    </div>
                    <p className="font-semibold text-slate-850 dark:text-white mt-1.5 font-sans">
                      Sender: {mov.fromDepartment} department ({mov.transferBy})
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                      Quantity Transferred: <strong className="text-indigo-600 dark:text-indigo-400">{mov.quantity} KG</strong> | Date: {new Date(mov.transferDate).toLocaleDateString([], {hour:'2-digit', minute:'2-digit'})}
                    </p>
                    {mov.remarks && (
                      <p className="mt-1 text-[10px] text-slate-400 bg-white dark:bg-slate-900 p-1.5 rounded italic">
                        "{mov.remarks}"
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 self-end md:self-auto shrink-0">
                    <button
                      onClick={() => onAcceptMovement(mov.movementId)}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold py-1.5 px-3 rounded-md transition duration-200 flex items-center gap-1"
                    >
                      <Check className="h-3 w-3" />
                      Accept Cargo
                    </button>
                    <button
                      onClick={() => {
                        setActiveRejectionId(isRejecting ? null : mov.movementId);
                        setRejectionNotes('');
                      }}
                      className="bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold py-1.5 px-3 rounded-md transition duration-200"
                    >
                      Reject Cargo
                    </button>
                  </div>
                </div>

                {isRejecting && (
                  <div className="mt-2 pt-3 border-t border-slate-200 text-xs space-y-2 bg-rose-50/20 dark:bg-rose-950/20 p-3 rounded-lg">
                    <label className="block text-rose-500 font-bold uppercase tracking-wider text-[9px]">
                      Provide Declinature / Rejection reason remarks
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Describe exact inspection failures (e.g. Dimensions incorrect, surface flaws, oxidation)..."
                      value={rejectionNotes}
                      onChange={e => setRejectionNotes(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-2 focus:outline-none focus:border-rose-500"
                    />
                    <div className="flex gap-1.5 justify-end">
                      <button
                        onClick={() => setActiveRejectionId(null)}
                        className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-3 py-1.5 rounded text-[10px] font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          if (!rejectionNotes) return;
                          onRejectMovement(mov.movementId, rejectionNotes);
                          setActiveRejectionId(null);
                        }}
                        disabled={!rejectionNotes}
                        className="bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded text-[10px] font-bold disabled:opacity-40"
                      >
                        Finalize Rejection Back to Sender
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
