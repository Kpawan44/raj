import React, { useState } from 'react';
import { Plus, Truck, X } from 'lucide-react';
import { JobCard, MaterialMovement, Department } from '../../types';
import { buildDispatchFinalizationUpdates } from '../../lib/departmentActions';

interface DispatchPanelProps {
  jobs: JobCard[];
  movements: MaterialMovement[];
  onCreateJobCard: (job: {
    partyName: string;
    itemName: string;
    itemCode: string;
    orderQty: number;
    heatTreatmentRequired: boolean;
    currentQty: number;
    currentDepartment: Department;
    status: 'Pending';
  }) => void;
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onAcceptMovement: (movementId: string, remarks?: string) => void;
  onSelectJobCard: (jobCard: JobCard) => void;
}

export default function DispatchPanel({
  jobs,
  movements,
  onCreateJobCard,
  onUpdateJobCard,
  onAcceptMovement,
  onSelectJobCard
}: DispatchPanelProps) {
  const [partyName, setPartyName] = useState('');
  const [itemName, setItemName] = useState('');
  const [itemCode, setItemCode] = useState('');
  const [orderQty, setOrderQty] = useState<number>(1000);
  const [htRequired, setHtRequired] = useState(false);
  const [dispatchRemarks, setDispatchRemarks] = useState('');

  const [activeDispJob, setActiveDispJob] = useState<string | null>(null);
  const [dispInvoice, setDispInvoice] = useState('INV-2026-');
  const [dispVehicle, setDispVehicle] = useState('MH-12-');
  const [dispQty, setDispQty] = useState<number>(0);

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyName || !itemName || !itemCode || orderQty <= 0) return;

    onCreateJobCard({
      partyName,
      itemName,
      itemCode,
      orderQty,
      heatTreatmentRequired: htRequired,
      currentQty: orderQty,
      currentDepartment: 'Production',
      status: 'Pending'
    });

    setPartyName('');
    setItemName('');
    setItemCode('');
    setOrderQty(1000);
    setHtRequired(false);
    setDispatchRemarks('');
  };

  const handleFinalizeDispatch = (job: JobCard) => {
    const updates = buildDispatchFinalizationUpdates(job, { invoiceNo: dispInvoice, vehicleNo: dispVehicle, qty: dispQty });
    if (!updates) return;

    onUpdateJobCard(job.jobCardNo, updates);

    const transitMov = movements.find(
      m => m.jobCardNo.toLowerCase() === job.jobCardNo.toLowerCase() && m.toDepartment === 'Dispatch' && !m.accepted
    );
    if (transitMov) {
      onAcceptMovement(transitMov.movementId, `Dispatched via Invoice ${dispInvoice}`);
    }

    setActiveDispJob(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Create Order Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 border-b pb-3 mb-2">
          <Plus className="h-5 w-5 text-[#3B82F6]" />
          <h3 className="font-sans font-bold text-sm text-slate-850 dark:text-white uppercase tracking-wider">
            Create Raw Job Card
          </h3>
        </div>

        <form onSubmit={handleCreateOrder} className="space-y-4 text-xs font-sans">
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Customer / Party Name</label>
            <input
              type="text"
              placeholder="Apex Engineering Solutions"
              required
              value={partyName}
              onChange={e => setPartyName(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-200 dark:border-slate-755 rounded-lg px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-[#3B82F6]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Item Name</label>
              <input
                type="text"
                placeholder="M12 High-Tensile Bolt"
                required
                value={itemName}
                onChange={e => setItemName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-200 dark:border-slate-755 rounded-lg px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-[#3B82F6]"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Item Code</label>
              <input
                type="text"
                placeholder="BOLT-M12-G8"
                required
                value={itemCode}
                onChange={e => setItemCode(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-200 dark:border-slate-755 rounded-lg px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-[#3B82F6] font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 items-center">
            <div>
              <label className="block text-slate-450 font-semibold mb-1">Quantity (KG)</label>
              <input
                type="number"
                min="1"
                required
                value={orderQty}
                onChange={e => setOrderQty(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-200 dark:border-slate-755 rounded-lg px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-[#3B82F6] font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-450 font-semibold mb-1">Heat Treatment Required</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setHtRequired(true)}
                  className={`flex-1 py-2 rounded-lg font-bold border transition cursor-pointer ${
                    htRequired
                      ? 'bg-[#3B82F6] border-[#1D4ED8] text-white shadow-sm'
                      : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-855 dark:hover:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-755'
                  }`}
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setHtRequired(false)}
                  className={`flex-1 py-2 rounded-lg font-bold border transition cursor-pointer ${
                    !htRequired
                      ? 'bg-[#3B82F6] border-[#1D4ED8] text-white shadow-sm'
                      : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-855 dark:hover:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-755'
                  }`}
                >
                  No
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">Remarks / Quality Notes</label>
            <textarea
              rows={2}
              placeholder="Enter raw wire material batch codes..."
              value={dispatchRemarks}
              onChange={e => setDispatchRemarks(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-200 dark:border-slate-755 rounded-lg p-2.5 text-slate-850 dark:text-slate-100 focus:outline-none focus:border-[#3B82F6] font-sans"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#3B82F6] text-white hover:bg-blue-600 font-semibold py-3 rounded-lg shadow-md transition-all uppercase tracking-wide font-mono text-sm border border-[#1D4ED8] cursor-pointer"
          >
            Register Order Sequence
          </button>
        </form>
      </div>

      {/* ACTIVE DISPATCH QUEUE & INVOICING / SHIPMENTS */}
      <div className="lg:col-span-2 space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="font-sans font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider mb-4">
            Verify & Ingest Inbound Packed Stocks to Dispatched
          </h3>

          {jobs.length === 0 ? (
            <div className="text-center py-10 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
              <span className="text-2xl">📦</span>
              <p className="text-slate-400 text-xs font-mono font-medium">No outstanding dispatch shipping queues</p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {jobs.map(job => {
                const isClosing = activeDispJob === job.jobCardNo;
                return (
                  <div
                    key={job.jobCardNo}
                    className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 transition-all hover:border-slate-350"
                  >
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
                      <div onClick={() => onSelectJobCard(job)} className="cursor-pointer hover:underline min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded">
                            {job.jobCardNo}
                          </span>
                          <span className="font-sans font-extrabold text-slate-900 dark:text-white truncate">
                            {job.partyName}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          <strong>{job.itemName}</strong> | target: {job.orderQty} KG, cur: {job.currentQty} KG (Bal: {job.balanceQty} KG)
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end md:self-auto">
                        {job.currentDepartment === 'Store' || job.currentDepartment === 'Completed' ? (
                          <button
                            onClick={() => {
                              setActiveDispJob(isClosing ? null : job.jobCardNo);
                              setDispQty(job.currentQty);
                            }}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold py-1.5 px-3 rounded-md transition-all flex items-center gap-1"
                          >
                            <Truck className="h-3.5 w-3.5" />
                            Invoice & Ship
                          </button>
                        ) : (
                          <span className="text-[10px] bg-slate-100 text-slate-500 dark:bg-slate-850 px-2.5 py-1.5 rounded-full font-mono">
                            Floor: {job.currentDepartment} ({job.status})
                          </span>
                        )}
                      </div>
                    </div>

                    {isClosing && (
                      <div className="mt-4 pt-4 border-t border-slate-201 text-xs space-y-3 font-sans">
                        <div className="flex items-center justify-between font-semibold mb-1">
                          <span>Outbound Logistics Sign-off</span>
                          <button onClick={() => setActiveDispJob(null)} className="p-1 rounded text-slate-400 hover:text-slate-600">
                            <X className="h-4 w-4" />
                          </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Invoice Number</label>
                            <input
                              type="text"
                              value={dispInvoice}
                              onChange={e => setDispInvoice(e.target.value)}
                              className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Vehicle / Carrier Registrations</label>
                            <input
                              type="text"
                              value={dispVehicle}
                              onChange={e => setDispVehicle(e.target.value)}
                              className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Final Dispatch quantity (KG)</label>
                            <input
                              type="number"
                              value={dispQty}
                              onChange={e => setDispQty(Math.max(0, parseInt(e.target.value) || 0))}
                              className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5 font-mono"
                            />
                          </div>
                        </div>

                        <p className="text-[10px] text-slate-400 font-sans italic">
                          *Completing this action closes the Job Card order chain and flags all movements Completed.
                        </p>

                        <button
                          onClick={() => handleFinalizeDispatch(job)}
                          className="w-full bg-emerald-600 text-white hover:bg-emerald-500 py-2 rounded font-bold uppercase tracking-wider text-xs shadow-sm mt-1"
                        >
                          Finalize Outbound Handover
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
