import React, { useState } from 'react';
import { Play, CheckCircle2 } from 'lucide-react';
import { JobCard, MaterialMovement, Department } from '../../types';
import { getJobCardProcessMetrics } from '../../lib/metrics';
import { getJobDeptDisplayMetrics } from '../../lib/departmentFilters';
import { getStatusBadgeStyleBordered } from '../../lib/badges';
import ProductionSubform from './subforms/ProductionSubform';
import HeatTreatmentSubform from './subforms/HeatTreatmentSubform';
import PlatingSubform from './subforms/PlatingSubform';
import PackingSubform from './subforms/PackingSubform';
import StoreSubform from './subforms/StoreSubform';

interface OperationsQueueProps {
  activeDept: Department;
  activeDepartmentJobs: JobCard[];
  movements: MaterialMovement[];
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onCreateMovement: (mov: any) => void;
  onSelectJobCard: (jobCard: JobCard) => void;
}

export default function OperationsQueue({
  activeDept,
  activeDepartmentJobs,
  movements,
  onUpdateJobCard,
  onCreateMovement,
  onSelectJobCard
}: OperationsQueueProps) {
  // Only one department renders at a time, so a single "currently expanded job" id suffices.
  const [activeJobId, setActiveJobId] = useState<string | null>(null);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
      <h3 className="font-sans font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
        ⚙️ In-Process Shop Floor Queue
      </h3>

      {activeDepartmentJobs.length === 0 ? (
        <div className="text-center py-10 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
          <span className="text-2xl">⚡</span>
          <p className="text-slate-400 text-xs font-mono font-medium">Floor queue clear. Await material ingestion or dispatch approvals.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {activeDepartmentJobs.map(job => {
            const isProcessing = activeJobId === job.jobCardNo;
            const disp = getJobDeptDisplayMetrics(job, movements, activeDept);
            const m = getJobCardProcessMetrics(job, movements);

            const handleStartProcessing = () => setActiveJobId(isProcessing ? null : job.jobCardNo);
            const handleClose = () => setActiveJobId(null);

            return (
              <div
                key={job.jobCardNo}
                className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col gap-3.5 hover:border-slate-350"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div onClick={() => onSelectJobCard(job)} className="cursor-pointer hover:underline min-w-0 flex-1">
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <span className="text-indigo-500 font-bold bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded">{job.jobCardNo}</span>
                      <span className={`px-2 py-0.2 rounded font-bold ${getStatusBadgeStyleBordered(job.status)}`}>{job.status}</span>
                    </div>
                    <p className="font-extrabold text-slate-900 dark:text-white mt-1.5 font-sans text-sm">
                      {job.partyName}
                    </p>

                    {activeDept === 'Production' || activeDept === 'Heat Treatment' || activeDept === 'Plating' || activeDept === 'Packing' ? (
                      <div className="space-y-1 mt-1.5">
                        <p className="text-xs text-slate-600 dark:text-slate-300 font-semibold">{job.itemName}</p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 bg-slate-100/70 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200/40">
                          <div>
                            <span className="block text-[10px] text-slate-400 uppercase font-bold">Total {activeDept === 'Production' ? 'Order' : 'Received'}</span>
                            <span className="text-xs font-bold font-mono text-slate-800 dark:text-white">{disp.totalReceived.toLocaleString()} KG</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-emerald-600 dark:text-emerald-450 uppercase font-bold">
                              {activeDept === 'Production' ? 'Produced & Routed' : activeDept === 'Heat Treatment' ? 'Hardened & Routed' : activeDept === 'Plating' ? 'Coated & Routed' : 'Packed & Routed'}
                            </span>
                            <span className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400">{disp.totalRouted.toLocaleString()} KG</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-amber-500 uppercase font-bold">Pending {activeDept}</span>
                            <span className="text-xs font-bold font-mono text-amber-600 dark:text-amber-400">{disp.pendingQty.toLocaleString()} KG</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-slate-400 uppercase font-bold">Current Custody</span>
                            <span className="text-xs font-mono font-medium text-indigo-600 dark:text-indigo-400">{job.currentDepartment} ({job.currentQty} KG)</span>
                          </div>
                        </div>
                        {disp.isRoutedDownstream && (
                          <div className="mt-1.5 text-[10.5px] text-indigo-600 dark:text-indigo-400 font-medium flex items-center gap-1 font-sans">
                            <span>↪️ Currently processing downstream at {job.currentDepartment}. Remaining pending quantity can be processed & transferred below.</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {job.itemName} • Order Qty: {job.orderQty} KG | <strong>Custody Weight: {job.currentQty} KG</strong> (Outstanding Balance: {job.balanceQty} KG)
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 self-end md:self-auto">
                    {job.status === 'Pending' || job.status === 'Rejected' ? (
                      <button
                        onClick={() => onUpdateJobCard(job.jobCardNo, { status: 'In Process' })}
                        className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11.5px] font-bold py-1.5 px-3.5 rounded-md transition flex items-center gap-1 leading-none"
                      >
                        <Play className="h-3.5 w-3.5 fill-current" />
                        Start Production Processing
                      </button>
                    ) : (
                      <button
                        onClick={handleStartProcessing}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white text-[11.5px] font-bold py-1.5 px-3.5 rounded-md transition flex items-center gap-1 leading-none"
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        Record Process Metrics
                      </button>
                    )}
                  </div>
                </div>

                {isProcessing && activeDept === 'Production' && (
                  <ProductionSubform
                    job={job}
                    movements={movements}
                    defaultQty={disp.pendingQty}
                    onUpdateJobCard={onUpdateJobCard}
                    onCreateMovement={onCreateMovement}
                    onClose={handleClose}
                  />
                )}

                {isProcessing && activeDept === 'Heat Treatment' && (
                  <HeatTreatmentSubform
                    job={job}
                    defaultQtyReceived={disp.pendingQty}
                    onUpdateJobCard={onUpdateJobCard}
                    onCreateMovement={onCreateMovement}
                    onClose={handleClose}
                  />
                )}

                {isProcessing && activeDept === 'Plating' && (
                  <PlatingSubform
                    job={job}
                    defaultQtyReceived={disp.pendingQty}
                    onUpdateJobCard={onUpdateJobCard}
                    onCreateMovement={onCreateMovement}
                    onClose={handleClose}
                  />
                )}

                {isProcessing && activeDept === 'Packing' && (
                  <PackingSubform
                    job={job}
                    defaultQtyReceived={disp.pendingQty}
                    onUpdateJobCard={onUpdateJobCard}
                    onCreateMovement={onCreateMovement}
                    onClose={handleClose}
                  />
                )}

                {isProcessing && activeDept === 'Store' && (
                  <StoreSubform
                    job={job}
                    defaultQtyReceived={m.qtyReceivedAtStore}
                    defaultQtySentToDispatch={m.qtyDispatched > 0 ? m.qtyDispatched : m.qtyReceivedAtStore}
                    onUpdateJobCard={onUpdateJobCard}
                    onCreateMovement={onCreateMovement}
                    onClose={handleClose}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
