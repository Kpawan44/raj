import React from 'react';
import { MaterialMovement } from '../../types';

interface CompletedLogsPanelProps {
  completedDepartmentLogs: MaterialMovement[];
}

export default function CompletedLogsPanel({ completedDepartmentLogs }: CompletedLogsPanelProps) {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
      <h3 className="font-sans font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider mb-4">
        📋 Completed Outbound Ledgers
      </h3>

      {completedDepartmentLogs.length === 0 ? (
        <div className="text-center py-10 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
          <span className="text-2xl">⏳</span>
          <p className="text-slate-400 text-xs font-mono font-medium">No archived outbound handoffs recorded in active session</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 font-mono text-[9px] text-slate-500 uppercase tracking-widest border-b border-slate-200 dark:border-slate-800">
                <th className="py-2.5 px-3">Job Card</th>
                <th className="py-2.5 px-3">Dispatched to</th>
                <th className="py-2.5 px-3">Handoff Weight</th>
                <th className="py-2.5 px-3">Recipient Signer</th>
                <th className="py-2.5 px-3">Handoff Date</th>
              </tr>
            </thead>
            <tbody>
              {completedDepartmentLogs.map(m => (
                <tr key={m.movementId} className="border-b last:border-b-0 border-slate-200 dark:border-slate-850 hover:bg-slate-50/50">
                  <td className="py-3 px-3 font-mono font-bold text-indigo-500">{m.jobCardNo}</td>
                  <td className="py-3 px-3 font-semibold">{m.toDepartment}</td>
                  <td className="py-3 px-3 font-mono font-semibold">{m.quantity} KG</td>
                  <td className="py-3 px-3">{m.acceptedBy || 'System auto-close'}</td>
                  <td className="py-3 px-3 text-slate-400 font-mono">
                    {new Date(m.acceptedDate || m.transferDate).toLocaleDateString([], {month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit'})}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
