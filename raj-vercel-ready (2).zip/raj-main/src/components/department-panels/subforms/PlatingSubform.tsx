import React, { useState } from 'react';
import { JobCard } from '../../../types';
import { completePlating } from '../../../lib/departmentActions';

interface PlatingSubformProps {
  job: JobCard;
  defaultQtyReceived: number;
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onCreateMovement: (mov: any) => void;
  onClose: () => void;
}

export default function PlatingSubform({ job, defaultQtyReceived, onUpdateJobCard, onCreateMovement, onClose }: PlatingSubformProps) {
  const [platingType, setPlatingType] = useState('Acid Zinc Plating (Yellow)');
  const [thickness, setThickness] = useState('8-12μm');
  const [duration, setDuration] = useState('45 min');
  const [rejectionQty, setRejectionQty] = useState<number>(0);
  const [qtyReceived] = useState<number>(defaultQtyReceived);
  const [qtySentToPacking, setQtySentToPacking] = useState<number>(defaultQtyReceived);

  const handleRejectionChange = (val: number) => {
    const rej = Math.max(0, val);
    if (rej > qtyReceived) {
      setRejectionQty(qtyReceived);
      setQtySentToPacking(0);
    } else {
      setRejectionQty(rej);
      setQtySentToPacking(Math.max(0, qtyReceived - rej));
    }
  };

  const handleQtySentChange = (val: number) => {
    const clamped = Math.max(0, val);
    setQtySentToPacking(clamped > qtyReceived ? qtyReceived : clamped);
  };

  const handleSave = () => {
    const result = completePlating(job, { platingType, thickness, duration, rejectionQty, qtyReceived, qtySentToPacking });
    if (!result) return;
    onUpdateJobCard(job.jobCardNo, result.jobUpdates);
    onCreateMovement(result.movement);
    onClose();
  };

  return (
    <div className="mt-3 pt-3 border-t border-slate-200 text-xs space-y-3 font-sans">
      <h4 className="font-semibold text-slate-800 dark:text-slate-100 uppercase text-[10px]">Record Coating Thickness & Route to Packing</h4>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div>
          <label className="block text-slate-400 mb-1">Cylinder Plating Bath Type</label>
          <input type="text" value={platingType} onChange={e => setPlatingType(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-slate-400 mb-1">Micron Thickness Verified (e.g. 5-10μm)</label>
          <input type="text" value={thickness} onChange={e => setThickness(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-slate-400 mb-1">Inductions Bath Duration</label>
          <input type="text" value={duration} onChange={e => setDuration(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-rose-500 font-semibold mb-1">Coating Rejection (KG)</label>
          <input
            type="number"
            value={rejectionQty}
            onChange={e => handleRejectionChange(parseInt(e.target.value) || 0)}
            className="w-full bg-white dark:bg-slate-900 border border-rose-200 focus:border-rose-500 rounded p-1.5 font-mono font-bold text-rose-600 dark:text-rose-455"
          />
        </div>
      </div>

      <div className="bg-slate-100/85 dark:bg-slate-900/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <h5 className="font-bold text-slate-700 dark:text-slate-350 text-[10px] uppercase tracking-wider flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-[#3B82F6] inline-block"></span>
          Material Quantity Allocation & Balance Tracker (Plating to Packing)
        </h5>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-slate-450 text-[10px] uppercase font-bold tracking-wider mb-1">Qty Received From HT/Prod (KG)</label>
            <input
              type="number"
              readOnly
              value={qtyReceived}
              className="w-full bg-slate-50 dark:bg-slate-900 font-mono font-extrabold text-[12px] text-blue-600 dark:text-blue-400 border border-slate-205 dark:border-slate-800 rounded p-1.5 focus:outline-none"
              title="Quantity received from Heat Treatment / Production (Unmodifiable)"
            />
          </div>

          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-purple-600 dark:text-purple-400 text-[10px] uppercase font-bold tracking-wider mb-1">Qty to Send for Packing (KG)</label>
            <input
              type="number"
              min="0"
              max={qtyReceived}
              value={qtySentToPacking}
              onChange={e => handleQtySentChange(parseInt(e.target.value) || 0)}
              className="w-full bg-white dark:bg-slate-950 font-mono font-extrabold text-[12px] text-purple-700 dark:text-purple-400 border border-purple-200 focus:border-purple-500 rounded p-1.5 focus:outline-none"
              title="How much quantity we send for Packing"
            />
          </div>

          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-amber-600 dark:text-amber-400 text-[10px] uppercase font-bold tracking-wider mb-1">Remaining/Pending Qty (KG)</label>
            <input
              type="number"
              readOnly
              value={Math.max(0, qtyReceived - qtySentToPacking - rejectionQty)}
              className="w-full bg-slate-50 dark:bg-slate-900 font-mono font-extrabold text-[12px] text-amber-700 dark:text-amber-400 border border-slate-205 dark:border-slate-800 rounded p-1.5 focus:outline-none"
              title="Pending Qty = Received from HT - Sent for Packing - Rejection"
            />
          </div>
        </div>
      </div>

      <div className="flex gap-2 pt-1">
        <button onClick={handleSave} className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 px-4 rounded font-bold uppercase tracking-wider text-xs shadow-sm cursor-pointer">
          Complete Coating & Route to packing
        </button>
        <button onClick={onClose} className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-4 py-2 rounded text-xs font-bold cursor-pointer">
          Cancel
        </button>
      </div>
    </div>
  );
}
