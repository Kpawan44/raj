import React, { useState } from 'react';
import { JobCard, MaterialMovement } from '../../../types';
import { completeProduction } from '../../../lib/departmentActions';

interface ProductionSubformProps {
  job: JobCard;
  movements: MaterialMovement[];
  defaultQty: number;
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onCreateMovement: (mov: any) => void;
  onClose: () => void;
}

export default function ProductionSubform({ job, movements, defaultQty, onUpdateJobCard, onCreateMovement, onClose }: ProductionSubformProps) {
  const [opName, setOpName] = useState('');
  const [qty, setQty] = useState<number>(defaultQty);

  const handleSave = () => {
    const result = completeProduction(job, movements, { operatorName: opName, qty });
    if (!result) return;
    onUpdateJobCard(job.jobCardNo, result.jobUpdates);
    onCreateMovement(result.movement);
    onClose();
  };

  return (
    <div className="mt-3 pt-3 border-t border-slate-200 text-xs space-y-3 font-sans">
      <h4 className="font-semibold text-slate-800 dark:text-slate-100 uppercase text-[10px]">Record Milling completion & Route Downstream</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="block text-slate-400 mb-1">Milling Lead Operator Name</label>
          <input
            type="text"
            placeholder="E.g. Ramesh Patil"
            value={opName}
            onChange={e => setOpName(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5 text-slate-800 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-slate-400 mb-1">Produced Quantity In KG</label>
          <input
            type="number"
            value={qty}
            onChange={e => setQty(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5 text-slate-800 focus:outline-none font-mono font-bold"
          />
        </div>
      </div>

      <div className="p-2.5 bg-indigo-50 dark:bg-slate-900 rounded font-sans text-[10px] text-slate-500">
        <strong>Business Routing Rule:</strong> {job.heatTreatmentRequired
          ? '⚠️ Heat Treatment is Required. Completing this step immediately transfers this job to the Furnace line queue.'
          : '✔️ Heat Treatment Skipped. Completing this step transfers cargo directly to Electroplating.'}
      </div>

      <div className="flex gap-2 pt-1">
        <button
          onClick={handleSave}
          disabled={!opName || qty <= 0}
          className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 px-4 rounded font-bold uppercase tracking-wider text-xs shadow-sm disabled:opacity-40"
        >
          Save Production Specs & Route Direct
        </button>
        <button
          onClick={onClose}
          className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-4 py-2 rounded text-xs font-bold"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
