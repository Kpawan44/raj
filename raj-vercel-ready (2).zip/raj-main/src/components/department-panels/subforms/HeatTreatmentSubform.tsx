import React, { useState } from 'react';
import { JobCard } from '../../../types';
import { completeHeatTreatment } from '../../../lib/departmentActions';

interface HeatTreatmentSubformProps {
  job: JobCard;
  defaultQtyReceived: number;
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onCreateMovement: (mov: any) => void;
  onClose: () => void;
}

export default function HeatTreatmentSubform({ job, defaultQtyReceived, onUpdateJobCard, onCreateMovement, onClose }: HeatTreatmentSubformProps) {
  const [hardness, setHardness] = useState('HRC 32-38');
  const [temp, setTemp] = useState('850°C');
  const [duration, setDuration] = useState('4 hours');
  const [rejectionQty, setRejectionQty] = useState<number>(0);
  const [qtyReceived] = useState<number>(defaultQtyReceived);
  const [qtySentToPlating, setQtySentToPlating] = useState<number>(defaultQtyReceived);

  const handleRejectionChange = (val: number) => {
    const rej = Math.max(0, val);
    if (rej > qtyReceived) {
      setRejectionQty(qtyReceived);
      setQtySentToPlating(0);
    } else {
      setRejectionQty(rej);
      setQtySentToPlating(Math.max(0, qtyReceived - rej));
    }
  };

  const handleQtySentChange = (val: number) => {
    const clamped = Math.max(0, val);
    setQtySentToPlating(clamped > qtyReceived ? qtyReceived : clamped);
  };

  const handleSave = () => {
    const result = completeHeatTreatment(job, { hardness, temp, duration, rejectionQty, qtyReceived, qtySentToPlating });
    if (!result) return;
    onUpdateJobCard(job.jobCardNo, result.jobUpdates);
    onCreateMovement(result.movement);
    onClose();
  };

  return (
    <div className="mt-3 pt-3 text-xs space-y-4 font-sans">
      <h4 className="font-semibold text-slate-800 dark:text-slate-100 uppercase text-[10px]">Record Hardness specs & Route to Plating</h4>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div>
          <label className="block text-slate-400 mb-1">Hardness Achieved (Spec Required)</label>
          <input type="text" value={hardness} onChange={e => setHardness(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-slate-400 mb-1">Hardening Temperature (°C)</label>
          <input type="text" value={temp} onChange={e => setTemp(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-slate-400 mb-1">Cycle Duration Time</label>
          <input type="text" value={duration} onChange={e => setDuration(e.target.value)} className="w-full bg-white dark:bg-slate-900 border border-slate-200 rounded p-1.5" />
        </div>
        <div>
          <label className="block text-rose-500 font-semibold mb-1">Furnace Rejection (KG)</label>
          <input
            type="number"
            value={rejectionQty}
            onChange={e => handleRejectionChange(parseInt(e.target.value) || 0)}
            className="w-full bg-white dark:bg-slate-900 border border-rose-200 focus:border-rose-500 rounded p-1.5 font-mono font-bold text-rose-600 dark:text-rose-455"
          />
        </div>
      </div>

      <div className="bg-slate-100/85 dark:bg-slate-900/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <h5 className="font-bold text-slate-700 dark:text-slate-350 text-[10px] uppercase tracking-wider flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-[#3B82F6] inline-block"></span>
          Material Quantity Allocation & Balance Tracker
        </h5>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-slate-450 text-[10px] uppercase font-bold tracking-wider mb-1">Qty Received From Prod (KG)</label>
            <input
              type="number"
              readOnly
              value={qtyReceived}
              className="w-full bg-slate-50 dark:bg-slate-900 font-mono font-extrabold text-[12px] text-blue-600 dark:text-blue-400 border border-slate-205 dark:border-slate-800 rounded p-1.5 focus:outline-none"
              title="Quantity received from Production (Unmodifiable)"
            />
          </div>

          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-purple-600 dark:text-purple-400 text-[10px] uppercase font-bold tracking-wider mb-1">Qty to Send to Plating (KG)</label>
            <input
              type="number"
              min="0"
              max={qtyReceived}
              value={qtySentToPlating}
              onChange={e => handleQtySentChange(parseInt(e.target.value) || 0)}
              className="w-full bg-white dark:bg-slate-950 font-mono font-extrabold text-[12px] text-purple-700 dark:text-purple-400 border border-purple-200 focus:border-purple-500 rounded p-1.5 focus:outline-none"
              title="How much quantity we send to Plating"
            />
          </div>

          <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
            <label className="block text-amber-600 dark:text-amber-400 text-[10px] uppercase font-bold tracking-wider mb-1">Remaining Balance Qty (KG)</label>
            <input
              type="number"
              readOnly
              value={Math.max(0, qtyReceived - qtySentToPlating - rejectionQty)}
              className="w-full bg-slate-50 dark:bg-slate-900 font-mono font-extrabold text-[12px] text-amber-700 dark:text-amber-400 border border-slate-205 dark:border-slate-800 rounded p-1.5 focus:outline-none"
              title="Remaining Quantity = Received - Sent to Plating - Rejection"
            />
          </div>
        </div>
      </div>

      <div className="flex gap-2 pt-1">
        <button onClick={handleSave} className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 px-4 rounded font-bold uppercase tracking-wider text-xs shadow-sm cursor-pointer">
          Save Furnace logs & Route to plating
        </button>
        <button onClick={onClose} className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-4 py-2 rounded text-xs font-bold cursor-pointer">
          Cancel
        </button>
      </div>
    </div>
  );
}
