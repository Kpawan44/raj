import React from 'react';
import { Factory, Mail, Lock, UserPlus, CheckCircle, ArrowLeft } from 'lucide-react';
import { UserProfile } from '../types';

interface LoginScreenProps {
  users: UserProfile[];
  isRegistering: boolean;
  setIsRegistering: (v: boolean) => void;
  regName: string;
  setRegName: (v: string) => void;
  regSuccess: string;
  setRegSuccess: (v: string) => void;
  authError: string;
  setAuthError: (v: string) => void;
  loginName: string;
  setLoginName: (v: string) => void;
  onLogin: (e: React.FormEvent) => void;
  onRegister: (e: React.FormEvent) => void;
  onDemoQuickLogin: (user: UserProfile) => void;
}

export default function LoginScreen({
  users,
  isRegistering,
  setIsRegistering,
  regName,
  setRegName,
  regSuccess,
  setRegSuccess,
  authError,
  setAuthError,
  loginName,
  setLoginName,
  onLogin,
  onRegister,
  onDemoQuickLogin
}: LoginScreenProps) {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center items-center p-4 font-sans selection:bg-[#3B82F6] selection:text-white">
      <div className="w-full max-w-4xl bg-white border border-[#E2E8F0] rounded-2xl shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-2">

        <div className="bg-[#0F172A] p-10 flex flex-col justify-between border-r border-[#1E293B]">
          <div className="flex items-center gap-3">
            <Factory className="h-7 w-7 text-[#3B82F6]" />
            <div>
              <h2 className="text-sm font-extrabold text-white tracking-widest leading-none uppercase">PRO-MFG TRACK</h2>
              <span className="font-mono text-[9px] uppercase tracking-wider text-slate-400 mt-1 block">Workforce Operations v2.5</span>
            </div>
          </div>

          <div className="my-10 space-y-4">
            <h3 className="text-xl font-bold tracking-tight text-white leading-snug">
              Professional Production & Fastener Tracking System
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Complete traceability ledger recording material flow across Dispatch, Production, Heat Treatment, Plating, Packing, and Warehouse lines.
            </p>
          </div>

          <div className="flex items-center gap-2.5 text-[10.5px] text-slate-500 font-mono">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Plant Node Status: Live Connection Established</span>
          </div>
        </div>

        <div className="p-8 md:p-10 flex flex-col justify-center bg-white space-y-6">
          {isRegistering ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 text-[#3B82F6]">
                  <UserPlus className="h-5 w-5" />
                  Manager Registration
                </h3>
                <p className="text-xs text-slate-500 mt-1">Establish administrative credentials. Only Manager level accounts can be registered from this screen.</p>
              </div>

              {authError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-[#B91C1C] text-xs leading-normal font-semibold">
                  {authError}
                </div>
              )}

              <form onSubmit={onRegister} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block text-slate-600 font-bold mb-1.5 uppercase tracking-wide text-[10px]">Full Name</label>
                  <input
                    type="text"
                    placeholder="e.g. John Doe"
                    required
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg px-4 py-2.5 text-slate-800 focus:outline-none focus:border-[#3B82F6] font-medium"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#3B82F6] hover:bg-blue-600 text-white font-bold py-3 rounded-lg shadow-sm transition-all uppercase tracking-wider font-mono text-xs cursor-pointer border border-[#1D4ED8]"
                >
                  Generate Manager Account
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  onClick={() => { setIsRegistering(false); setAuthError(''); }}
                  className="text-xs text-[#3B82F6] hover:underline font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="h-3.5 w-3.5" /> Back to Login
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 text-[#3B82F6]">
                  <Lock className="h-5 w-5" />
                  Personnel Access Port
                </h3>
                <p className="text-xs text-slate-500 mt-1">Enter your registered Name to access the workstation terminal.</p>
              </div>

              {regSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2 font-semibold">
                  <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{regSuccess}</span>
                </div>
              )}

              {authError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-[#B91C1C] text-xs leading-normal font-semibold">
                  {authError}
                </div>
              )}

              <form onSubmit={onLogin} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block text-slate-600 font-bold mb-1.5 uppercase tracking-wide text-[10px]">Registered Full Name</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-450" />
                    <input
                      type="text"
                      placeholder="e.g. Pawan Kumar"
                      required
                      value={loginName}
                      onChange={e => setLoginName(e.target.value)}
                      className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg pl-10 pr-4 py-2.5 text-slate-800 focus:outline-none focus:border-[#3B82F6] font-medium"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#3B82F6] hover:bg-blue-600 text-white font-bold py-3 rounded-lg shadow-sm transition-all uppercase tracking-wider font-mono text-xs cursor-pointer border border-[#1D4ED8]"
                >
                  Access Workspace Terminal
                </button>
              </form>

              <div className="border-t border-[#E2E8F0] pt-4">
                <div className="flex justify-between items-center mb-2.5">
                  <label className="block text-[10px] text-[#3B82F6] font-bold uppercase tracking-wider">
                    🛠️ Quick Log In (Simulate Personnel PIN)
                  </label>
                  <button
                    onClick={() => { setIsRegistering(true); setAuthError(''); setRegSuccess(''); }}
                    className="text-xs text-[#3B82F6] hover:underline font-extrabold flex items-center gap-1 cursor-pointer"
                  >
                    <UserPlus className="h-3.5 w-3.5" /> Manager Signup
                  </button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {users.slice(0, 6).map(user => (
                    <button
                      key={user.userId}
                      onClick={() => onDemoQuickLogin(user)}
                      className="p-2 rounded bg-[#F8FAFC] hover:bg-[#EFF6FF] text-[10px] text-slate-700 border border-[#E2E8F0] transition text-left truncate hover:border-[#BFDBFE] cursor-pointer"
                    >
                      <strong className="text-[#1D4ED8]">{user.department}</strong>
                      <span className="block text-[9px] text-slate-500 truncate mt-0.5">{user.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <p className="text-[10px] text-slate-450 mt-6 font-mono text-center">
        Secured with robust token ledger tracking.
      </p>
    </div>
  );
}
