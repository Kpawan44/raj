import React, { useState } from 'react';
import { Search, Filter, Trash2 } from 'lucide-react';
import { JobCard, MaterialMovement, UserProfile } from '../types';
import { getJobCardProcessMetrics } from '../lib/metrics';
import { getStatusBadgeStyleCompact } from '../lib/badges';
import { DBService } from '../lib/firebase';

interface AllOrdersViewProps {
  jobCards: JobCard[];
  movements: MaterialMovement[];
  currentUser: UserProfile | null;
  onSelectJobCard: (job: JobCard) => void;
  onCreateSubJob: (parentJob: JobCard) => void;
  onRefresh: () => void;
}

export default function AllOrdersView({
  jobCards,
  movements,
  currentUser,
  onSelectJobCard,
  onCreateSubJob,
  onRefresh
}: AllOrdersViewProps) {
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const filteredOrders = jobCards.filter(j => {
    const searchMatch =
      j.jobCardNo.toLowerCase().includes(search.toLowerCase()) ||
      j.partyName.toLowerCase().includes(search.toLowerCase()) ||
      j.itemName.toLowerCase().includes(search.toLowerCase()) ||
      j.itemCode.toLowerCase().includes(search.toLowerCase());

    const deptMatch = deptFilter === 'All' || j.currentDepartment === deptFilter;
    const statusMatch = statusFilter === 'All' || j.status === statusFilter;

    return searchMatch && deptMatch && statusMatch;
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-1">
        <div>
          <h3 className="font-sans font-bold text-lg text-slate-805 dark:text-white uppercase tracking-wider">
            Manufacturing Job Cards Database
          </h3>
          <p className="text-xs text-slate-400 italic">Entire plant ledger registry containing live queues</p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between text-xs">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Job Card No, Party Name, Item..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-slate-50 dark:bg-slate-850 pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-210 dark:border-slate-750 w-full focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex flex-wrap gap-2.5 items-center w-full md:w-auto">
          <div className="flex items-center gap-1.5">
            <Filter className="h-3.5 w-3.5 text-slate-400" />
            <span className="text-slate-400 text-[11px] uppercase font-bold">Line Filter</span>
          </div>

          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-200 focus:outline-none"
          >
            <option value="All">All Lines</option>
            <option value="Production">Production Milling</option>
            <option value="Heat Treatment">Heat Treatment Line</option>
            <option value="Plating">Surface Plating</option>
            <option value="Packing">Packing Line</option>
            <option value="Store">Storehouse</option>
            <option value="Completed">Completed Dispatch</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-200 focus:outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Process">In Process</option>
            <option value="Pending Acceptance">Pending Acceptance</option>
            <option value="Rejected">Rejected</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          {filteredOrders.length === 0 ? (
            <div className="text-center p-12 space-y-1.5">
              <span className="text-2xl">🔍</span>
              <p className="text-sm font-semibold text-slate-450 font-mono">No active Job Cards match database filter parameters</p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 text-[10px] text-slate-405 uppercase tracking-wider font-mono border-b border-slate-200 dark:border-slate-800">
                  <th className="py-3 px-3">Job Card</th>
                  <th className="py-3 px-3">Party Name</th>
                  <th className="py-3 px-3">Item Details</th>
                  <th className="py-3 px-3">Target (KG)</th>
                  <th className="py-3 px-3">Pending (KG)</th>
                  <th className="py-3 px-3">Action</th>

                  <th className="py-3 px-2 bg-blue-50/55 dark:bg-blue-950/25 text-blue-800 dark:text-blue-300 font-bold border-x border-slate-200/50 dark:border-slate-800/40 text-center">Recv (PROD)</th>
                  <th className="py-3 px-2 bg-blue-50/55 dark:bg-blue-950/25 text-blue-800 dark:text-blue-300 font-bold text-center">Rout (PLAT)</th>
                  <th className="py-3 px-2 bg-blue-50/55 dark:bg-blue-950/25 text-blue-800 dark:text-blue-300 font-bold border-r border-slate-200/50 dark:border-slate-800/40 text-center">Remain (PROD)</th>

                  <th className="py-3 px-2 bg-purple-50/55 dark:bg-purple-950/25 text-purple-800 dark:text-purple-300 font-bold text-center">Recv (PLAT)</th>
                  <th className="py-3 px-2 bg-purple-50/55 dark:bg-purple-950/25 text-purple-800 dark:text-purple-300 font-bold border-x border-slate-200/50 dark:border-slate-800/40 text-center">Rout (PACK)</th>
                  <th className="py-3 px-2 bg-purple-50/55 dark:bg-purple-950/25 text-purple-800 dark:text-purple-300 font-bold border-r border-slate-200/50 dark:border-slate-800/40 text-center">Remain (PLAT)</th>

                  <th className="py-3 px-2 bg-pink-50/55 dark:bg-pink-950/25 text-pink-800 dark:text-pink-300 font-bold text-center">Recv (PACK)</th>
                  <th className="py-3 px-2 bg-pink-50/55 dark:bg-pink-950/25 text-pink-800 dark:text-pink-300 font-bold border-x border-slate-200/50 dark:border-slate-800/40 text-center">Rout (STOR)</th>
                  <th className="py-3 px-2 bg-pink-50/55 dark:bg-pink-950/25 text-pink-800 dark:text-pink-300 font-bold border-r border-slate-200/50 dark:border-slate-800/40 text-center">Remain (PACK)</th>

                  <th className="py-3 px-2 bg-emerald-50/55 dark:bg-emerald-950/25 text-emerald-800 dark:text-emerald-300 font-bold text-center">Dispatched</th>
                  <th className="py-3 px-2 bg-emerald-50/55 dark:bg-emerald-950/25 text-emerald-800 dark:text-emerald-300 font-bold border-l border-slate-200/50 dark:border-slate-800/40 text-center">In Stock</th>

                  <th className="py-3 px-3">Position</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 text-center">Details</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map(j => {
                  const m = getJobCardProcessMetrics(j, movements);
                  const movedForJob = movements.filter(mv => mv.jobCardNo.toLowerCase() === j.jobCardNo.toLowerCase());
                  const totalMoved = movedForJob.reduce((acc, curr) => acc + curr.quantity, 0);
                  const pendingQty = j.orderQty - totalMoved;

                  return (
                    <tr key={j.jobCardNo} className="border-b last:border-b-0 border-slate-200 dark:border-slate-850 hover:bg-slate-50/50 dark:hover:bg-slate-850/20 text-slate-700 dark:text-slate-300">
                      <td className="py-3 px-3 font-mono font-bold text-indigo-500 whitespace-nowrap">{j.jobCardNo}</td>
                      <td className="py-3 px-3 font-semibold text-slate-850 dark:text-slate-100 whitespace-nowrap leading-tight">{j.partyName}</td>
                      <td className="py-2 px-3">
                        <span className="block font-medium truncate max-w-[120px] text-slate-800 dark:text-slate-200" title={j.itemName}>{j.itemName}</span>
                        <span className="text-[9px] font-mono text-slate-400">{j.itemCode}</span>
                      </td>
                      <td className="py-3 px-3 font-mono font-bold">{j.orderQty.toLocaleString()}</td>
                      <td className="py-3 px-3 font-mono font-bold">{pendingQty.toLocaleString()}</td>
                      <td className="py-3 px-3">
                        {pendingQty > 0 && (
                          <button
                            onClick={() => onCreateSubJob(j)}
                            className="px-2 py-1 bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200 rounded text-[9px] font-bold uppercase hover:bg-amber-200"
                          >
                            Create Sub-Job
                          </button>
                        )}
                      </td>

                      <td className="py-3 px-2 bg-blue-50/10 dark:bg-blue-950/10 font-mono font-bold text-blue-700 dark:text-blue-400 border-x border-slate-200/30 text-center">{m.qtyReceivedFromProd.toLocaleString()}</td>
                      <td className="py-2 px-2 bg-blue-50/10 dark:bg-blue-950/10 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <input
                            type="number"
                            min="0"
                            title="Edit Routed to Plating Quantity"
                            className="w-20 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded px-1.5 py-0.5 text-center font-mono font-medium text-blue-600 dark:text-blue-350 hover:border-slate-300 dark:hover:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
                            value={j.customRoutedToPlating !== undefined && j.customRoutedToPlating !== null ? j.customRoutedToPlating : m.qtyRoutedToPlating}
                            onChange={async (e) => {
                              const val = e.target.value === '' ? null : Number(e.target.value);
                              try {
                                await DBService.updateJobCard(j.jobCardNo, {
                                  customRoutedToPlating: val !== null ? val : undefined
                                }, currentUser?.userId || 'u-1', currentUser?.name || 'Pawan Kumar');
                                onRefresh();
                              } catch (err) {
                                console.error("Failed to update custom Routed Plating value", err);
                              }
                            }}
                          />
                          <span className="text-[9px] text-slate-400 font-sans">KG</span>
                        </div>
                      </td>
                      <td className="py-3 px-2 bg-blue-50/10 dark:bg-blue-950/10 font-mono text-blue-500 dark:text-blue-300 text-center border-r border-slate-200/30">{m.qtyRemainingAtProd.toLocaleString()}</td>

                      <td className="py-3 px-2 bg-purple-50/10 dark:bg-purple-950/10 font-mono font-semibold text-purple-700 dark:text-purple-400 text-center">{m.qtyReceivedAtPlating.toLocaleString()}</td>
                      <td className="py-3 px-2 bg-purple-50/10 dark:bg-purple-950/10 font-mono text-purple-600 dark:text-purple-350 text-center border-x border-slate-200/30">{m.qtyRoutedToPacking.toLocaleString()}</td>
                      <td className="py-3 px-2 bg-purple-50/10 dark:bg-purple-950/10 font-mono text-purple-500 dark:text-purple-300 text-center border-r border-slate-200/30">{m.qtyRemainingAtPlating.toLocaleString()}</td>

                      <td className="py-3 px-2 bg-pink-50/10 dark:bg-pink-950/10 font-mono font-semibold text-pink-700 dark:text-pink-400 text-center">{m.qtyReceivedAtPacking.toLocaleString()}</td>
                      <td className="py-3 px-2 bg-pink-50/10 dark:bg-pink-950/10 font-mono text-pink-650 dark:text-pink-350 text-center border-x border-slate-200/30">{m.qtyRoutedToStore.toLocaleString()}</td>
                      <td className="py-3 px-2 bg-pink-50/10 dark:bg-pink-950/10 font-mono text-pink-500 dark:text-pink-300 text-center border-r border-slate-200/30">{m.qtyRemainingAtPacking.toLocaleString()}</td>

                      <td className="py-3 px-2 bg-emerald-50/10 dark:bg-emerald-950/10 font-mono text-emerald-700 dark:text-emerald-400 text-center">{m.qtyDispatched.toLocaleString()}</td>
                      <td className="py-3 px-2 bg-emerald-50/10 dark:bg-emerald-950/10 font-mono font-bold text-emerald-600 dark:text-emerald-300 text-center border-l border-slate-200/30">{m.qtyRemainingInStock.toLocaleString()}</td>

                      <td className="py-3 px-3 font-medium text-slate-500 whitespace-nowrap">{j.currentDepartment}</td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getStatusBadgeStyleCompact(j.status)}`}>
                          {j.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onSelectJobCard(j)}
                            className="text-[10.5px] font-bold text-amber-500 hover:bg-amber-500/10 px-2.5 py-1.5 rounded transition"
                          >
                            Details
                          </button>
                          {(currentUser?.role === 'admin' || currentUser?.department === 'Admin') && (
                            <button
                              onClick={async () => {
                                if (window.confirm(`Are you sure you want to permanently delete Job Card ${j.jobCardNo}? This action is completely irreversible!`)) {
                                  try {
                                    await DBService.deleteJobCard(j.jobCardNo, currentUser?.userId || 'u-1', currentUser?.name || 'Pawan Kumar');
                                    alert(`Job Card ${j.jobCardNo} has been deleted successfully.`);
                                    onRefresh();
                                  } catch (err: any) {
                                    console.error("Failed to delete job card", err);
                                    alert(`Failed to delete Job Card: ${err instanceof Error ? err.message : String(err)}`);
                                  }
                                }
                              }}
                              className="p-1 px-1.5 rounded text-red-500 hover:bg-red-500/10 transition"
                              title="Admin: Delete Selected Job Card"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
