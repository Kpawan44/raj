import React from 'react';
import { X, FileSpreadsheet } from 'lucide-react';

interface GoogleSheetsModalProps {
  onClose: () => void;
  feedback: string;
  onConnect: () => void;
}

export default function GoogleSheetsModal({ onClose, feedback, onConnect }: GoogleSheetsModalProps) {
  return (
    <div className="fixed inset-0 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative font-sans">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition cursor-pointer"
          id="btn_close_sheets_modal"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3 border-b pb-4 mb-4">
          <div className="h-10 w-10 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
            <FileSpreadsheet className="h-6 w-6" id="header_sheets_icon" />
          </div>
          <div>
            <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm">Google Sheets Logbook Syncer</h3>
            <p className="text-[11px] text-slate-400 font-medium">Real-time ledger accounting for fastener production flows</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-sans">
          <p>
            Link your Google Sheets account to sync all transactions, movements, and rejections dynamically:
          </p>

          <ul className="list-disc pl-5 space-y-2 text-slate-500 font-sans">
            <li>Records new Customer Job Cards & Route Targets automatically.</li>
            <li>Logs step-by-step Department records (Heat Treatment, Plating, Packing, Warehouse).</li>
            <li>Calculates and logs Furnace, Coating, and Boxing rejections (KG weight metrics).</li>
            <li>Inserts audit action timestamps and personnel sign-off names.</li>
          </ul>

          {feedback && (
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 text-[#3B82F6] dark:text-blue-400 rounded-lg text-xs font-semibold border border-blue-200 dark:border-blue-900/40 flex items-center gap-2 font-mono">
              <span className="h-2 w-2 rounded-full bg-blue-500 animate-ping shrink-0" />
              <span>{feedback}</span>
            </div>
          )}

          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={onConnect}
              className="w-full bg-[#107C41] hover:bg-[#0B592E] text-white font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 shadow-sm transition uppercase tracking-wider text-[11px] font-mono cursor-pointer border border-[#0B5927]"
              id="btn_auth_sheets"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Link via Google Account</span>
            </button>
            <p className="text-[9.5px] text-center text-slate-450 font-light pt-1">
              Secure OAuth token integration. Google Sheets permission is sandbox restricted to spreadsheets created by this app.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
