import React, { useState } from 'react';
import { JobCard, MaterialMovement, Department, UserProfile } from '../types';
import { getActiveDepartmentJobs, getIncomingTransfers, getCompletedDepartmentLogs } from '../lib/departmentFilters';
import DispatchPanel from './department-panels/DispatchPanel';
import IncomingTransfersPanel from './department-panels/IncomingTransfersPanel';
import OperationsQueue from './department-panels/OperationsQueue';
import CompletedLogsPanel from './department-panels/CompletedLogsPanel';

interface DepartmentOperationsProps {
  currentUser: UserProfile;
  jobCards: JobCard[];
  movements: MaterialMovement[];
  onCreateJobCard: (job: {
    partyName: string;
    itemName: string;
    itemCode: string;
    orderQty: number;
    heatTreatmentRequired: boolean;
    currentQty: number;
    currentDepartment: Department;
    status: 'Pending';
  }) => void;
  onUpdateJobCard: (jobCardNo: string, updates: Partial<JobCard>) => void;
  onCreateMovement: (mov: {
    jobCardNo: string;
    fromDepartment: Department;
    toDepartment: Department | 'Completed';
    quantity: number;
    remarks?: string;
  }) => void;
  onAcceptMovement: (movementId: string, remarks?: string) => void;
  onRejectMovement: (movementId: string, remarks: string) => void;
  onSelectJobCard: (jobCard: JobCard) => void;
}

/**
 * Top-level department workbench. This component only owns the "which
 * department / which sub-view am I looking at" concerns and the derived
 * queues; the actual forms and business logic live in ./department-panels
 * and ../lib/departmentActions so each department's workflow can be
 * read (and changed) independently of the others.
 */
export default function DepartmentOperations({
  currentUser,
  jobCards,
  movements,
  onCreateJobCard,
  onUpdateJobCard,
  onCreateMovement,
  onAcceptMovement,
  onRejectMovement,
  onSelectJobCard
}: DepartmentOperationsProps) {
  const activeDept = currentUser.department === 'Admin' ? 'Dispatch' : (currentUser.department as Department);
  const [activeSubView, setActiveSubView] = useState<'incoming' | 'operations' | 'completed'>('operations');

  const incomingTransfers = getIncomingTransfers(activeDept, movements);
  const activeDepartmentJobs = getActiveDepartmentJobs(activeDept, jobCards, movements);
  const completedDepartmentLogs = getCompletedDepartmentLogs(activeDept, movements);

  return (
    <div className="space-y-6">
      {/* Department Context Top bar */}
      <div className="bg-[#0F172A] text-white rounded-2xl p-5 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[#3B82F6] text-[10px] uppercase font-bold tracking-widest font-mono">
            Active Control Module
          </span>
          <h2 className="text-xl font-bold tracking-tight text-white mt-1">
            {activeDept} Department Workbench
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {activeDept === 'Dispatch' ? 'Initiate customer bookings & execute shipping schedules.' : 'Monitor local queue, accept incoming batches, and record processing metadata.'}
          </p>
        </div>

        {activeDept !== 'Dispatch' && (
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs text-slate-400 self-start md:self-auto shrink-0">
            <button
              onClick={() => setActiveSubView('incoming')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all relative ${
                activeSubView === 'incoming' ? 'bg-slate-800 text-white shadow' : 'hover:text-white'
              }`}
            >
              Incoming Ingress
              {incomingTransfers.length > 0 && (
                <span className="absolute -top-1.5 -right-1 bg-red-500 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center animate-bounce">
                  {incomingTransfers.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveSubView('operations')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                activeSubView === 'operations' ? 'bg-slate-800 text-white shadow' : 'hover:text-white'
              }`}
            >
              Active Floor Jobs
            </button>
            <button
              onClick={() => setActiveSubView('completed')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all ${
                activeSubView === 'completed' ? 'bg-slate-800 text-white shadow' : 'hover:text-white'
              }`}
            >
              Completed / Shipped Logs
            </button>
          </div>
        )}
      </div>

      {activeDept === 'Dispatch' && (
        <DispatchPanel
          jobs={activeDepartmentJobs}
          movements={movements}
          onCreateJobCard={onCreateJobCard}
          onUpdateJobCard={onUpdateJobCard}
          onAcceptMovement={onAcceptMovement}
          onSelectJobCard={onSelectJobCard}
        />
      )}

      {activeDept !== 'Dispatch' && (
        <div className="space-y-4">
          {activeSubView === 'incoming' && (
            <IncomingTransfersPanel
              incomingTransfers={incomingTransfers}
              onAcceptMovement={onAcceptMovement}
              onRejectMovement={onRejectMovement}
            />
          )}

          {activeSubView === 'operations' && (
            <OperationsQueue
              activeDept={activeDept}
              activeDepartmentJobs={activeDepartmentJobs}
              movements={movements}
              onUpdateJobCard={onUpdateJobCard}
              onCreateMovement={onCreateMovement}
              onSelectJobCard={onSelectJobCard}
            />
          )}

          {activeSubView === 'completed' && (
            <CompletedLogsPanel completedDepartmentLogs={completedDepartmentLogs} />
          )}
        </div>
      )}
    </div>
  );
}
