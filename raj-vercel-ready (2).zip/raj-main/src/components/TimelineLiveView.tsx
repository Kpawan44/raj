import React from 'react';
import { JobCard, MaterialMovement } from '../types';
import TimelineVisual from './TimelineVisual';

interface TimelineLiveViewProps {
  jobCards: JobCard[];
  movements: MaterialMovement[];
  onSelectJobByNo: (jobNo: string) => void;
}

export default function TimelineLiveView({ jobCards, movements, onSelectJobByNo }: TimelineLiveViewProps) {
  return (
    <div className="space-y-4">
      <div className="px-1">
        <h3 className="font-sans font-bold text-lg text-slate-850 dark:text-white uppercase tracking-wider">
          Real-Time Chronological Transit Ledger
        </h3>
        <p className="text-xs text-slate-400 italic">Continuous live logging capturing exact component coordinates</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
          <h4 className="font-sans font-bold text-sm uppercase tracking-wider text-slate-500 border-b pb-2 mb-2">
            Chronological Queue Transfers Ledger
          </h4>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {movements.map((mov) => (
              <div
                key={mov.movementId}
                className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl space-y-2 text-xs hover:border-slate-350"
              >
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded text-[10px]">
                    {mov.jobCardNo}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(mov.transferDate).toLocaleDateString([], {hour: '2-digit', minute:'2-digit'})}
                  </span>
                </div>

                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {mov.fromDepartment} → {mov.toDepartment}
                </p>

                <div className="flex justify-between items-center font-mono text-[10px] text-slate-500 mt-1">
                  <span>Mass moved: <strong>{mov.quantity} KG</strong></span>
                  <span>Billed By: {mov.transferBy}</span>
                </div>

                {mov.accepted ? (
                  <div className="text-[9px] bg-emerald-500/10 text-emerald-600 font-bold p-1 rounded flex items-center gap-1 mt-1">
                    ✔️ Custody accepted by {mov.acceptedBy} on {new Date(mov.acceptedDate!).toLocaleDateString([], {hour:'2-digit', minute:'2-digit'})}
                  </div>
                ) : (
                  <div className="text-[9px] bg-purple-500/10 text-purple-600 font-bold p-1 rounded flex items-center gap-1 mt-1">
                    ⌛ Transit verification pending at downstream
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-slate-900 border border-slate-800 text-white rounded-xl">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-1.5 col-span-2">
              Interactive Live Trace Inspector
            </h4>
            <p className="text-[11px] text-slate-400 leading-normal">
              Select any active manufacturing batch from the drop-down below to visualize their position in the 7-node chain.
            </p>

            <div className="relative mt-3">
              <select
                onChange={(e) => onSelectJobByNo(e.target.value)}
                className="w-full bg-slate-800 text-white text-xs py-2 px-3 pr-8 rounded border border-slate-700 font-mono cursor-pointer"
              >
                <option value="">-- Select Active Job Card --</option>
                {jobCards.map(c => (
                  <option key={c.jobCardNo} value={c.jobCardNo}>
                    [{c.jobCardNo}] - {c.itemName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {jobCards.length > 0 && (
            <TimelineVisual
              jobCard={jobCards[0]}
              movements={movements.filter(m => m.jobCardNo.toLowerCase() === jobCards[0].jobCardNo.toLowerCase())}
            />
          )}
        </div>
      </div>
    </div>
  );
}
