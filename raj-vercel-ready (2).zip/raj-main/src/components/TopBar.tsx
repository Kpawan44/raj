import React, { useState } from 'react';
import { Bell, Scan, LogOut, X, Menu } from 'lucide-react';
import { AppNotification } from '../types';

interface TopBarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
  isSheetsActive: boolean;
  sheetsUrl?: string;
  onOpenSheetsModal: () => void;
  onDisconnectSheets: () => void;
  onOpenScanner: () => void;
  filteredNotifications: AppNotification[];
  unreadNotificationsCount: number;
  onMarkNotifRead: (id: string) => void;
  onMarkAllNotifsRead: () => void;
  onLogout: () => void;
}

export default function TopBar({
  sidebarOpen,
  setSidebarOpen,
  isSheetsActive,
  sheetsUrl,
  onOpenSheetsModal,
  onDisconnectSheets,
  onOpenScanner,
  filteredNotifications,
  unreadNotificationsCount,
  onMarkNotifRead,
  onMarkAllNotifsRead,
  onLogout
}: TopBarProps) {
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState(false);

  return (
    <header className="h-16 border-b border-[#E2E8F0] dark:border-slate-850 px-6 flex items-center justify-between bg-white dark:bg-slate-900 shrink-0 select-none print:hidden">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-1.5 -ml-1 text-slate-500 hover:text-slate-705 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-805 rounded-lg transition-all cursor-pointer"
          title="Toggle Sidebar Menu"
          id="btn_toggle_sidebar"
        >
          <Menu className="h-5 w-5" />
        </button>
        <span className="text-xs text-slate-500 font-bold uppercase tracking-wider bg-[#F1F5F9] dark:bg-slate-850 py-1 px-3 rounded-full font-mono hidden sm:inline-block">
          Active Plant: Site #1
        </span>
      </div>

      <div className="flex items-center gap-3 relative">
        {isSheetsActive ? (
          <div className="flex items-center gap-1.5">
            <a
              href={sheetsUrl || "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/35 dark:hover:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/45 text-emerald-700 dark:text-emerald-400 text-xs font-semibold font-sans transition-all"
              title="Open live Google Sheets logbook in a new tab"
            >
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="hidden leading-none md:inline">Sheets Synced</span>
            </a>
            <button
              onClick={onDisconnectSheets}
              className="p-1.5 text-xs text-rose-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
              title="Disconnect Google Sheets sync"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenSheetsModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-semibold transition cursor-pointer"
            title="Connect real-time Google Sheets for logbook updates"
          >
            <div className="h-2 w-2 rounded-full bg-slate-350" />
            <span>Link Google Sheets</span>
          </button>
        )}

        <button
          onClick={onOpenScanner}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-semibold transition cursor-pointer"
          title="Align Job Card Barcode to local Scanner"
        >
          <Scan className="h-4 w-4 text-[#3B82F6]" />
          <span>Barcode Scanner</span>
        </button>

        <div className="relative">
          <button
            onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-600 dark:text-slate-200 transition relative cursor-pointer"
            title="Active Plant Announcements"
          >
            <Bell className="h-4 w-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white font-bold h-4 w-4 rounded-full flex items-center justify-center text-[8.5px] animate-pulse">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {showNotificationsDropdown && (
            <div className="absolute right-0 mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xl w-80 z-40 space-y-3">
              <div className="flex items-center justify-between border-b pb-2 mb-1">
                <span className="font-bold text-xs text-slate-905 dark:text-white uppercase tracking-wider">
                  Announcements Ledger ({filteredNotifications.length})
                </span>
                <button
                  onClick={() => { onMarkAllNotifsRead(); setShowNotificationsDropdown(false); }}
                  className="text-[10px] text-[#3B82F6] hover:underline font-bold cursor-pointer"
                >
                  Clear All
                </button>
              </div>

              {filteredNotifications.length === 0 ? (
                <p className="text-[10px] text-slate-400 italic font-mono py-2 text-center">No active system alerts recorded</p>
              ) : (
                <div className="space-y-2.5 max-h-60 overflow-y-auto">
                  {filteredNotifications.map(notif => (
                    <div
                      key={notif.notificationId}
                      onClick={() => onMarkNotifRead(notif.notificationId)}
                      className={`p-2 rounded-lg text-[11px] border transition cursor-pointer ${
                        notif.read
                          ? 'bg-slate-50 dark:bg-slate-950/20 border-slate-100 dark:border-slate-850 text-slate-500'
                          : 'bg-blue-500/10 border-blue-500/25 text-slate-800 dark:text-blue-400 font-medium'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <strong>{notif.title}</strong>
                        <span className="font-mono text-[8px] text-slate-400">
                          {new Date(notif.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                      </div>
                      <p className="mt-1 leading-normal text-slate-600 dark:text-slate-350">{notif.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <button
          onClick={onLogout}
          className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-rose-500 transition cursor-pointer"
          title="Sign Out of Crew Terminal"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
